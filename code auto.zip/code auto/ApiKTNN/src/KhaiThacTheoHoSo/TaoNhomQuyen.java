package KhaiThacTheoHoSo;

import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

import static io.restassured.RestAssured.given;
import org.testng.Assert;

public class TaoNhomQuyen {
	public static void main(String[] args) {
		RestAssured.baseURI = "https://sohoa-ktnn-api-dev.vais.vn";
		TaoNhomQuyen khaiThacHS = new TaoNhomQuyen();

		String password = "dev@12345";
		String maHSMo = "b89d4409-da2d-4dab-bd6f-b829854e624b";
		// Thông tin nhóm 1
		String GroupName1 = "Nhóm 1";
		String MaCuocKT1 = "1302";
		String[] listHoSo1 = { "b53fe3f6-1c85-4929-902f-bcefa7660e62", "098df89f-050e-474e-87b3-877904cef143" };
		Object[][] listThanhVien1 = { { "D72D0ABD-E7B6-40EB-8C03-36F05D08CAE2", true, false },
				{ "8374F6F7-1324-4D9E-AA77-63C7EA8190E0", true, true } };
		String startDate1 = "12/20/2023"; // mm/dd/yyyy
		String expiredDate1 = "01/20/2024";

//		get access token và login
		String adminAccessToken = khaiThacHS.login("vendor_test1", password);
		String username1 = khaiThacHS.get_username(adminAccessToken, listThanhVien1[0][0].toString());
		String username2 = khaiThacHS.get_username(adminAccessToken, listThanhVien1[1][0].toString());
		String UserAccessToken1 = khaiThacHS.login(username1, password);
		String UserAccessToken2 = khaiThacHS.login(username2, password);

//    	check tạo nhóm
		khaiThacHS.taoNhom(adminAccessToken, GroupName1, MaCuocKT1, listHoSo1, listThanhVien1, startDate1,expiredDate1);
		khaiThacHS.create_fail_with_unexist_time(adminAccessToken, "x", MaCuocKT1, listHoSo1, listThanhVien1,"31/02/2023", expiredDate1);
		khaiThacHS.create_fail_with_startTime_bigger_expiredTime(adminAccessToken, "x", MaCuocKT1, listHoSo1,listThanhVien1, "12/02/2024", "12/01/2024");
		khaiThacHS.create_fail_with_exist_name(adminAccessToken, GroupName1, MaCuocKT1, listHoSo1, listThanhVien1,startDate1, expiredDate1);
		khaiThacHS.create_fail_with_blank_name(adminAccessToken, "", MaCuocKT1, listHoSo1, listThanhVien1, startDate1,expiredDate1);
		khaiThacHS.create_fail_with_blank_name(adminAccessToken, "  ", MaCuocKT1, listHoSo1, listThanhVien1,startDate1, expiredDate1);
		khaiThacHS.create_fail_with_expiredTime_smaller_currentDay(adminAccessToken, "x", MaCuocKT1, listHoSo1,listThanhVien1, "12/12/2023", "12/15/2023");

//    	check sửa nhóm
		khaiThacHS.capNhatNhom(adminAccessToken, GroupName1, MaCuocKT1, listHoSo1, listThanhVien1, "12/01/2023",expiredDate1);

//    	check quyền của user
		khaiThacHS.check_user_khong_quyen_khai_thac(UserAccessToken1, "1308", "62e90935-d92b-4cad-ae8f-035f4c137f4a"); // String accessToken, maCuocKT, maHoSo
		khaiThacHS.check_user_co_quyen_xem_va_tai(UserAccessToken2, MaCuocKT1, listHoSo1[0]);
		khaiThacHS.check_user_co_quyen_xem_va_khong_tai(UserAccessToken1, MaCuocKT1, listHoSo1[0]);
		khaiThacHS.check_user_khong_co_quyen_voi_HS_mo(UserAccessToken2, MaCuocKT1, maHSMo);

//		check sửa trạng thái nhóm quyền
		khaiThacHS.change_fail_status_nhom_quyen_with_unexist_idNhom(adminAccessToken, "6531fa6061cccefaaaaaaaaa", "ACTIVE"); // String accessToken, String idNhom, String statusNhom
		khaiThacHS.change_success_status_nhom_quyen(adminAccessToken, GroupName1, "DISABLED"); // String accessToken, nameNhom, statusNhom
		// check user không có quyền sau khi đổi status nhóm 1 thành DISABLED (hết hạn)
		khaiThacHS.check_user_khong_quyen_khai_thac(UserAccessToken1, MaCuocKT1, listHoSo1[0]);
		// đổi lại status nhóm thành active
		khaiThacHS.change_success_status_nhom_quyen(adminAccessToken, GroupName1, "ACTIVE");

//		check xóa nhóm phân quyền
		khaiThacHS.delete_fail_nhom_quyen_with_unexist_idNhom(adminAccessToken, "6531fa6061cccefaaaaaaaaa"); // String accessToken, idNhom
		khaiThacHS.delete_success_nhom_quyen(adminAccessToken, GroupName1);
		// check user không có quyền sau khi xóa nhóm
		khaiThacHS.check_user_khong_quyen_khai_thac(UserAccessToken1, MaCuocKT1, listHoSo1[0]);

		System.out.println("CHECK DONE CHỨC NĂNG PHÂN QUYỀN KHAI THÁC");
	}
	
	// API login
	public String login(String username, String password) {
		String LoginResponse = given().log().all().header("Content-Type", "application/json")
				.body(PayloadRequest.dangNhapPayload(username, password)).when().post("/api/v1/auth/login-dev").then()
				.log().all().assertThat().statusCode(200).extract().response().asString();
		System.out.println(LoginResponse);
		JsonPath js = new JsonPath(LoginResponse);
		String Msg = js.getString("message");
		String accessToken = js.getString("data.accessToken");
		Assert.assertEquals(Msg, "Đăng nhập thành công");
		return accessToken;
	}

	// API get username theo mã thành viên
	public String get_username(String accessToken, String MaThanhVien) {
		String getDSResponse = given().log().all().header("Content-Type", "application/json")
				.header("Authorization", "Bearer " + accessToken).queryParam("filter[MaThanhVien]", MaThanhVien).when()
				.get("/api/v1/thanh-vien").then().log().all().assertThat().statusCode(200).extract().response()
				.asString();
		JsonPath js = new JsonPath(getDSResponse);
		String JsUsername = js.getString("data.items.TenDangNhap"); // output: "[username]"
		String username = JsUsername.substring(1, JsUsername.length() - 1);
		// String username = JsUsername.replace("[", "").replace("]", "");
		return username;
	}

	// API Tạo phân quyền khai thác -> check statusCode, added to list nhóm phân
	// quyền
	public Response taoNhom(String accessToken, String GroupName, String MaCuocKT, String[] listHoSo,
			Object[][] listThanhVien, String startDate, String expiredDate) {
		Response resp = given().log().all().header("Content-Type", "application/json")
				.body(PayloadRequest.taoNhomPayload(GroupName, MaCuocKT, listHoSo, listThanhVien, startDate,
						expiredDate))
				.header("Authorization", "Bearer " + accessToken).when().post("/api/v1/phan-quyen-khai-thac");
		int statusCode = resp.getStatusCode();
		if (statusCode == 200) {
			String createResponse = resp.then().log().all().extract().response().asString();
			JsonPath jsTaoNhom = new JsonPath(createResponse);
			String createName = jsTaoNhom.getString("data.record.name");
			Assert.assertTrue(createName.contains(GroupName));

			String statusNhom = jsTaoNhom.getString("data.record.status");
			Assert.assertTrue(statusNhom.contains("ACTIVE"));

			JsonPath jsListNhom = getListNhom(accessToken);
			String listNhom = jsListNhom.getString("data");
			Assert.assertTrue(listNhom.contains(GroupName));
		}
		return resp;
	}

	public String getIdNhom(String accessToken, String nameNhom) {
		JsonPath jsListNhom = getListNhom(accessToken);
		int size = jsListNhom.getInt("data.items.size()");
		String idNhom = "";
		for (int i = 0; i < size; i++) {
			String name = jsListNhom.getString("data.items[" + i + "].name");
			if (name.contains(nameNhom)) {
				idNhom = jsListNhom.getString("data.items[" + i + "].id");
			}
		}
		return idNhom;
	}

//	 API danh sách hồ sơ của thành viên
//	 check danh sách hồ sơ được phân công của user
	public void check_list_HS_khai_thac_cua_user(String accessToken) 
	{
		String[] listHoSo1 = { "b53fe3f6-1c85-4929-902f-bcefa7660e62", "098df89f-050e-474e-87b3-877904cef143" };
		Object[][] listThanhVien1 = { { "9516AA0C-E7ED-4967-ADB8-6E5FF2A3587B", true, false },
				{ "AF371942-1408-475B-AE6D-5439A8CEE87D", true, true } };

		String resp = given().log().all().header("Content-Type", "application/json")
				.queryParam("filter[MaThanhVien]", "9516AA0C-E7ED-4967-ADB8-6E5FF2A3587B")
				.header("Authorization", "Bearer " + accessToken)
				.when().get("/api/v1/phan-quyen-khai-thac/danh-sach-ho-so-cua-thanh-vien")
				.then().log().all().assertThat().statusCode(200)
				.extract().response().asString();
		JsonPath js = new JsonPath(resp);
		for (int i = 0; i < listHoSo1.length; i++) {
			Assert.assertTrue(resp.contains(listHoSo1[i]));
		}
	}

	// API Lấy danh sách phân quyền khai thác
	public JsonPath getListNhom(String accessToken) {
		String GetListResponse = given().log().all().header("Content-Type", "application/json")
				.header("Authorization", "Bearer " + accessToken).when().get("/api/v1/phan-quyen-khai-thac").then()
				.log().all().assertThat().statusCode(200).extract().response().asString();
		JsonPath js = new JsonPath(GetListResponse);
		String getListData = js.getString("data");
		System.out.println(getListData);
		return js;
	}

	// API cập nhật phân quyền khai thác
	public Response capNhatNhom(String accessToken, String GroupName, String MaCuocKT, String[] listHoSo,
			Object[][] listThanhVien, String startDate, String expiredDate) {
		Response resp = given().log().all().header("Content-Type", "application/json")
				.body(PayloadRequest.taoNhomPayload(GroupName, MaCuocKT, listHoSo, listThanhVien, startDate,
						expiredDate))
				.header("Authorization", "Bearer " + accessToken).when().patch("/api/v1/phan-quyen-khai-thac");
		int statusCode = resp.getStatusCode();
		if (statusCode == 200) {
			String createResponse = resp.then().log().all().extract().response().asString();
			JsonPath jsTaoNhom = new JsonPath(createResponse);
			String createName = jsTaoNhom.getString("data.record.name");
			Assert.assertTrue(createName.contains(GroupName));

			JsonPath jsListNhom = getListNhom(accessToken);
			String listNhom = jsListNhom.getString("data");
			Assert.assertTrue(listNhom.contains(GroupName));
		}
		return resp;
	}

	// GET status nhóm quyền
	public String get_status_nhom_quyen(String accessToken, String nameNhom) {
		String idNhom = getIdNhom(accessToken, nameNhom);
		String resp = given().log().all().header("Content-type", "application/json").pathParam("id", idNhom)
				.header("Authorization", "Bearer " + accessToken).when().get("/api/v1/phan-quyen-khai-thac/{id}").then()
				.log().all().assertThat().statusCode(200).extract().response().asString();
		JsonPath js = new JsonPath(resp);
		String status_nhom = js.getString("data.record.status");
		return status_nhom;
	}

	// API thay đổi status của nhóm quyền
	public void change_success_status_nhom_quyen(String accessToken, String nameNhom, String statusNhom) {
		String idNhom = getIdNhom(accessToken, nameNhom);
		String resp = given().log().all().header("Content-type", "application/json").pathParam("id", idNhom)
				.header("Authorization", "Bearer " + accessToken).body(PayloadRequest.changeStatusNhom(statusNhom))
				.when().patch("/api/v1/phan-quyen-khai-thac/{id}/cap-nhat-trang-thai").then().log().all().assertThat()
				.statusCode(200).extract().response().asString();
		JsonPath js = new JsonPath(resp);
		String status_nhom = js.getString("data.record.status");
		System.out.println("Status của nhóm là: " + status_nhom);
	}

	public void change_fail_status_nhom_quyen_with_unexist_idNhom(String accessToken, String idNhom,
			String statusNhom) {
		String resp = given().log().all().header("Content-type", "application/json").pathParam("id", idNhom)
				.header("Authorization", "Bearer " + accessToken).body(PayloadRequest.changeStatusNhom(statusNhom))
				.when().patch("/api/v1/phan-quyen-khai-thac/{id}/cap-nhat-trang-thai").then().log().all().assertThat()
				.statusCode(404).extract().response().asString();
		JsonPath js = new JsonPath(resp);
		String message = js.getString("message");
		Assert.assertTrue(message.contains("Không tìm thấy"));
	}

	
	
	
	// API delete nhóm quyền
	public void delete_success_nhom_quyen(String accessToken, String nameNhom) {
		String idNhom = getIdNhom(accessToken, nameNhom);
		String resp = given().log().all().header("Content-type", "application/json").pathParam("id", idNhom)
				.header("Authorization", "Bearer " + accessToken).when().delete("/api/v1/phan-quyen-khai-thac/{id}")
				.then().log().all().assertThat().statusCode(200).extract().response().asString();
		JsonPath js = getListNhom(accessToken);
		String getListData = js.getString("data");
		Assert.assertFalse(getListData.contains(nameNhom));
	}

	public void delete_fail_nhom_quyen_with_unexist_idNhom(String accessToken, String idNhom) {
		String resp = given().log().all().header("Content-type", "application/json").pathParam("id", idNhom)
				.header("Authorization", "Bearer " + accessToken).when().delete("/api/v1/phan-quyen-khai-thac/{id}")
				.then().log().all().assertThat().statusCode(404).extract().response().asString();
		JsonPath js = new JsonPath(resp);
		String message = js.getString("message");
		Assert.assertTrue(message.contains("Không tìm thấy"));
	}

	// API xem chi tiết tài liệu
	public Response chi_tiet_tai_lieu(String accessToken, String idTaiLieu) {
		Response resp = given().log().all().header("Content-Type", "application/json")
				.header("Authorization", "Bearer " + accessToken).pathParam("id", idTaiLieu).when()
				.get("/api/v1/tai-lieu/{id}");
		return resp;
	}

	// API lấy tài liệu theo mã cuộc và mã hồ sơ
	public JsonPath danh_sach_tai_lieu_theo_ho_so(String accessToken, String maCuocKT, String maHoSo) {
		String getDSResponse = given().log().all().header("Content-Type", "application/json")
				.header("Authorization", "Bearer " + accessToken).queryParam("filter[MaCuocKiemToan]", maCuocKT)
				.queryParam("filter[MaHoSo]", maHoSo).when().get("/api/v1/tai-lieu/danh-sach-theo-loai-tai-lieu").then()
				.log().all().assertThat().statusCode(200).extract().response().asString();
		JsonPath js = new JsonPath(getDSResponse);
		return js;
	}

// TEST CASE	

	// check create fail: unexist day
	public void create_fail_with_unexist_time(String accessToken, String GroupName, String MaCuocKT, String[] listHoSo,
			Object[][] listThanhVien, String startDate, String expiredDate) {
		Response resp = taoNhom(accessToken, GroupName, MaCuocKT, listHoSo, listThanhVien, startDate, expiredDate);
		Assert.assertEquals(resp.getStatusCode(), 400);

		String createResponse = resp.then().log().all().extract().response().asString();
		JsonPath js = new JsonPath(createResponse);

		String createName = js.getString("message");
		Assert.assertTrue(createName.contains("Cast to date failed for value"));
		String createData = js.getString("data");
		Assert.assertEquals(createData, null);
	}

	// check create fail: startDay > endDay
	public void create_fail_with_startTime_bigger_expiredTime(String accessToken, String GroupName, String MaCuocKT,
			String[] listHoSo, Object[][] listThanhVien, String startDate, String expiredDate) {
		Response resp = taoNhom(accessToken, GroupName, MaCuocKT, listHoSo, listThanhVien, startDate, expiredDate);
		Assert.assertEquals(resp.getStatusCode(), 400);

		String createResponse = resp.then().log().all().extract().response().asString();
		JsonPath js = new JsonPath(createResponse);

		String createName = js.getString("message");
		Assert.assertTrue(createName.contains("Thời gian bắt đầu không thể lớn hơn thời gian kết thúc"));
		String createData = js.getString("data");
		Assert.assertEquals(createData, null);
	}

	// check create fail: startDay < endDay < ngày hiện tại
	public void create_fail_with_expiredTime_smaller_currentDay(String accessToken, String GroupName, String MaCuocKT,
			String[] listHoSo, Object[][] listThanhVien, String startDate, String expiredDate) {
		Response resp = taoNhom(accessToken, GroupName, MaCuocKT, listHoSo, listThanhVien, startDate, expiredDate);
		Assert.assertEquals(resp.getStatusCode(), 400);

		String createResponse = resp.then().log().all().extract().response().asString();
		JsonPath js = new JsonPath(createResponse);

		String createName = js.getString("message");
		Assert.assertTrue(createName.contains("Thời gian khai thác không hợp lệ"));
		String createData = js.getString("data");
		Assert.assertEquals(createData, null);
	}

	// check create fail: exist group name
	public void create_fail_with_exist_name(String accessToken, String GroupName, String MaCuocKT, String[] listHoSo,
			Object[][] listThanhVien, String startDate, String expiredDate) {
		JsonPath js = getListNhom(accessToken);
		String listNhom = js.getString("data");

		boolean isGroupNameExist = listNhom.contains(GroupName);
		if (isGroupNameExist == false) {
			taoNhom(accessToken, GroupName, MaCuocKT, listHoSo, listThanhVien, startDate, expiredDate);
		}
		Response resp = taoNhom(accessToken, GroupName, MaCuocKT, listHoSo, listThanhVien, startDate, expiredDate);
		Assert.assertEquals(resp.getStatusCode(), 409);

		String createResponse = resp.then().log().all().extract().response().asString();
		JsonPath jsTaoNhom = new JsonPath(createResponse);

		String createName = jsTaoNhom.getString("message");
		Assert.assertTrue(createName.contains("Tên nhóm đã tồn tại trên hệ thống"));
		String createData = jsTaoNhom.getString("data");
		Assert.assertEquals(createData, null);
	}

	// check create fail: blank name
	public void create_fail_with_blank_name(String accessToken, String GroupName, String MaCuocKT, String[] listHoSo,
			Object[][] listThanhVien, String startDate, String expiredDate) {
		Response resp = taoNhom(accessToken, GroupName, MaCuocKT, listHoSo, listThanhVien, startDate, expiredDate);
		Assert.assertEquals(resp.getStatusCode(), 404);

		String createResponse = resp.then().log().all().extract().response().asString();
		JsonPath js = new JsonPath(createResponse);

		String createName = js.getString("message");
		Assert.assertTrue(createName.contains("Không tìm thấy tên quyền khai thác"));
		String createData = js.getString("data");
		Assert.assertEquals(createData, null);
	}

	// check quyền của user
	public void check_user_khong_quyen_khai_thac(String accessToken, String maCuocKT, String maHoSo) {
		JsonPath jsDsTL = danh_sach_tai_lieu_theo_ho_so(accessToken, maCuocKT, maHoSo);
		int count = jsDsTL.getInt("data.items.DanhSachTaiLieu.size()");
		for (int i = 0; i < count; i++) {
			String isView = jsDsTL.getString("data.items.DanhSachTaiLieu[" + i + "].isView");
			String isDownload = jsDsTL.getString("data.items.DanhSachTaiLieu[" + i + "].isDownload");
			String statusHoSo = jsDsTL.getString("data.items.DanhSachTaiLieu[" + i + "].HoSo.TrangThai");
			if (statusHoSo.contains("CLOSE")) {
				Assert.assertTrue(isView.contains("false"));
				Assert.assertTrue(isDownload.contains("false"));

			} else {
				System.out.println("Hồ sơ đang mở, mặc định không có quyền khai thác.");
			}
		}
	}

	// check quyền khi user có cả quyền xem và tải
	public void check_user_co_quyen_xem_va_tai(String accessToken, String maCuocKT, String maHoSo) {
		JsonPath jsDsTL = danh_sach_tai_lieu_theo_ho_so(accessToken, maCuocKT, maHoSo);
		int count = jsDsTL.getInt("data.items.DanhSachTaiLieu.size()");
		for (int i = 0; i < count; i++) {
			String isView = jsDsTL.getString("data.items.DanhSachTaiLieu[" + i + "].isView");
			String isDownload = jsDsTL.getString("data.items.DanhSachTaiLieu[" + i + "].isDownload");
			String statusHoSo = jsDsTL.getString("data.items.DanhSachTaiLieu[" + i + "].HoSo.TrangThai");
			if (statusHoSo.contains("CLOSE")) {
				Assert.assertTrue(isView.contains("true"));
				Assert.assertTrue(isDownload.contains("true"));

			} else {
				System.out.println("Hồ sơ đang mở, mặc định không có quyền khai thác.");
			}
		}
	}

	// check quyền khi user có cả quyền xem và không có quyền tải
	public void check_user_co_quyen_xem_va_khong_tai(String accessToken, String maCuocKT, String maHoSo) {
		JsonPath jsDsTL = danh_sach_tai_lieu_theo_ho_so(accessToken, maCuocKT, maHoSo);
		int count = jsDsTL.getInt("data.items.DanhSachTaiLieu.size()");
		for (int i = 0; i < count; i++) {
			String isView = jsDsTL.getString("data.items.DanhSachTaiLieu[" + i + "].isView");
			String isDownload = jsDsTL.getString("data.items.DanhSachTaiLieu[" + i + "].isDownload");
			String statusHoSo = jsDsTL.getString("data.items.DanhSachTaiLieu[" + i + "].HoSo.TrangThai");
			if (statusHoSo.contains("CLOSE")) {
				Assert.assertTrue(isView.contains("true"));
				Assert.assertTrue(isDownload.contains("false"));

			} else {
				System.out.println("Hồ sơ đang mở, mặc định không có quyền khai thác.");
			}
		}
	}

	// check user không có cả quyền xem và tải khi hồ sơ mở
	public void check_user_khong_co_quyen_voi_HS_mo(String accessToken, String maCuocKT, String maHoSo) {
		JsonPath jsDsTL = danh_sach_tai_lieu_theo_ho_so(accessToken, maCuocKT, maHoSo);
		int count = jsDsTL.getInt("data.items.DanhSachTaiLieu.size()");
		for (int i = 0; i < count; i++) {
			String isView = jsDsTL.getString("data.items.DanhSachTaiLieu[" + i + "].isView");
			String isDownload = jsDsTL.getString("data.items.DanhSachTaiLieu[" + i + "].isDownload");
			String statusHoSo = jsDsTL.getString("data.items.DanhSachTaiLieu[" + i + "].HoSo.TrangThai");
			if (statusHoSo.contains("OPEN")) {
				Assert.assertTrue(isView.contains("false"));
				Assert.assertTrue(isDownload.contains("false"));

			} else {
				System.out.println("Vui lòng chọn hồ sơ đang đóng để kiểm tra.");
			}
		}
	}

}
