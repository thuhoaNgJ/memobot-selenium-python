package KhaiThacTheoHoSo;

import static io.restassured.RestAssured.given;

import org.testng.Assert;

import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;

public class Test {

	public static void main(String[] args) {
		RestAssured.baseURI = "https://sohoa-ktnn-api-dev.vais.vn";
		Test run = new Test();
		run.dangNhap("","");
	}
	public String dangNhap(String username, String password)
	{
		String loginResponse = given().log().all()
				.header("Content-Type","application/json")
				.body("{\r\n"
						+ "    \"username\" : \"{{username}}\",\r\n"
						+ "    \"password\" :\"{{password}}\"\r\n"
						+ "}")
				.when().post("/api/v1/auth/login-dev")
				.then().log().all().assertThat().statusCode(200).extract().response().asString();
		System.out.println(loginResponse);
		JsonPath js = new JsonPath(loginResponse);
		String msg = js.getString("message");
		String accessToken = js.getString("data.accessToken");
		Assert.assertTrue(msg.contains("Đăng nhập thành công"));
		return accessToken;
		
	}

	
	
	public String login(String username, String password) {
		String LoginResponse = given().log().all().header("Content-Type", "application/json")
				.body(PayloadRequest.dangNhapPayload(username, password)).when().post("/api/v1/auth/login-dev").then()
				.log().all().assertThat().statusCode(200).extract().response().asString();
		System.out.println(LoginResponse);
		JsonPath js = new JsonPath(LoginResponse);
		String Msg = js.getString("message");
		String accessToken = js.getString("data.accessToken");
		Assert.assertEquals(Msg, "Đăng nhập thành công");
		return accessToken;
	}
	
}
