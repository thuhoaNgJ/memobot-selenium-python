package KhaiThacTheoHoSo;

public class PayloadRequest {
	
	public static String dangNhapPayload(String username, String password)
	{
		return "{\r\n"
				+ "    \"username\" : \"" + username + "\",\r\n"
				+ "    \"password\" :\"" + password + "\"\r\n"
				+ "}";
	}
	
	public static String taoNhomPayload(String GroupName, String MaCuocKT, 
			String[] listHoSo, Object[][] listThanhVien, String startDate, String expiredDate)
	{
    	String jsonString = "{\r\n" +
    	        " \"record\": {\r\n" +
    	        " \"name\": \"" + GroupName + "\",\r\n" +
    	        " \"DanhSachPhanCong\": [\r\n" +
    	        " {\r\n" +
    	        " \"MaCuocKiemToan\": \"" + MaCuocKT + "\",\r\n" +
    	        " \"DanhSachMaHoSo\": [\r\n";

    	for (int i = 0; i < listHoSo.length; i++) {
    	    jsonString += " \"" + listHoSo[i] + "\"";
    	    if (i < listHoSo.length - 1) {
    	        jsonString += ",\r\n";
    	    }
    	}

    	jsonString += " ]\r\n" +
    	        " }\r\n" +
    	        " ],\r\n" +
    	        " \"PhanCongThanhVien\": [\r\n";

    	for (int i = 0; i < listThanhVien.length; i++) {
    	    jsonString += " {\r\n" +
    	            " \"MaThanhVien\": \"" + listThanhVien[i][0] + "\",\r\n" +
    	            " \"XEM_TAI_LIEU\": " + listThanhVien[i][1] + ",\r\n" +
    	            " \"TAI_VE_TAI_LIEU\": " + listThanhVien[i][2] + "\r\n" +
    	            " }";

    	    if (i < listThanhVien.length - 1) {
    	        jsonString += ",\r\n";
    	    }
    	}

    	jsonString += "\r\n],\r\n" +
    	        " \"startDate\": \"" + startDate + "\",\r\n" +
    	        " \"expiredDate\": \"" + expiredDate + "\"\r\n" +
    	        " }\r\n" +
    	        "}";
    	return jsonString;
	}
	
	public static String changeStatusNhom(String status)
	{
		return "{\r\n"
				+ "    \"record\": {\r\n"
				+ "        \"status\": \"" + status + "\"\r\n"
				+ "    }\r\n"
				+ "}";
	}
	
}
