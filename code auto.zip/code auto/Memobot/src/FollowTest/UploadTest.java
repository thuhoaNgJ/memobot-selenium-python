package FollowTest;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import me.xuender.unidecode.Unidecode;

import java.time.Duration;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class UploadTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// TODO Auto-generated method stub
		ChromeOptions co = new ChromeOptions();
		co.addArguments("--remote-allow-origins=*");
		System.setProperty("webdriver.chrome.driver", "/Users/admin/Downloads/chromedriver/chromedriver-win64/chromedriver.exe");
		WebDriver driver = new ChromeDriver(co);
		driver.get("https://memobot.io/");
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("sign-in")));
		
//		Test login
		driver.findElement(By.id("sign-in")).click();
		wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector("input[placeholder='Email']")));
		driver.findElement(By.cssSelector("input[placeholder='Email']")).sendKeys("yuichan712@gmail.com");
		driver.findElement(By.cssSelector("input[placeholder='Mật khẩu']")).sendKeys("123456789");
		driver.findElement(By.id("web-login")).click();
		System.out.println("login successful");
		
//		Test upload file exceeded capacity
		wait.until(ExpectedConditions.elementToBeClickable(By.id("upload-audio")));
		driver.findElement(By.cssSelector("input[name='file']")).sendKeys("C://Users/admin/Downloads/Test01.mp3");
        
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("div[class='audio_title']")));
//		Get current date time now
		LocalDateTime now = LocalDateTime.now();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy , HH:mm");
        String formattedDateTime = now.format(formatter);
        String timeUpload = driver.findElement(By.xpath("(//div[@class='audio_time mb-4'])[1]")).getText();
        Assert.assertEquals(timeUpload, formattedDateTime);
        System.out.println(timeUpload);
        System.out.println("Done test time upload of audio");
        
		String text1 = driver.findElement(By.cssSelector("div[class='p-4 audio_item position-rl status_error'] > div:nth-child(3)")).getText();
		Assert.assertEquals(text1, "Gói của bạn không hỗ trợ upload audio có thời lượng lâu, vui lòng nâng cấp gói cước để tiếp tục sử dụng");
		System.out.println("Done test alert upload file exceeded capacity in HomePage");

//		Test watch audio's document
		driver.findElement(By.cssSelector("div[class='p-4 audio_item position-rl status_error'] > div:nth-child(4) > div:first-child")).click();
		wait.until(ExpectedConditions.urlContains("type=record"));
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("div[class = 'no-data'] > div > span")));
		String failAudioText = driver.findElement(By.cssSelector("div[class='text-center'] > div:first-child > div:first-child > span:first-child > div:nth-child(2)")).getText();
		Assert.assertTrue(failAudioText.contains("Có vẻ như bạn đã dùng hết dung lượng gói trong tháng này"));
		System.out.println("Done test alert upload file exceeded capacity in document's screen");
		driver.navigate().back();
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("div[class='audio_title']")));
		
		driver.findElement(By.xpath("(//button[@id='delete_transcript'])[1]")).click();
		Assert.assertEquals(driver.findElement(By.xpath("//h2[@class='my-4 m-auto text-center']")).getText(), "Xóa bản ghi âm");
		driver.findElement(By.cssSelector("div[class$='el-dialog__body'] > div:first-child > div:last-child > button:first-child")).click();//button Quay lại
		driver.findElement(By.xpath("(//button[@id='delete_transcript'])[1]")).click();
		driver.findElement(By.cssSelector("div[class$='el-dialog__body'] > div:first-child > div:last-child > button:last-child")).click();//delete audio
		System.out.print("Delete audio successfully");

		
	}
}
