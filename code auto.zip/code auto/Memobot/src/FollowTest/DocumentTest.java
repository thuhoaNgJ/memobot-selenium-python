package FollowTest;

import java.time.Duration;
import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import me.xuender.unidecode.Unidecode;

public class DocumentTest {

	public static void main(String[] args) throws InterruptedException {
		ChromeOptions co = new ChromeOptions();
		co.addArguments("--remote-allow-origins=*");
		System.setProperty("webdriver.chrome.driver", "/Users/admin/Downloads/chromedriver/chromedriver-win64/chromedriver.exe");
		WebDriver driver = new ChromeDriver(co);
		driver.get("https://memobot.io/");
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("sign-in")));
		
//		Test login
		driver.findElement(By.id("sign-in")).click();
		wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector("input[placeholder='Email']")));
		driver.findElement(By.cssSelector("input[placeholder='Email']")).sendKeys("nguyenthuhoa712@gmail.com");
		driver.findElement(By.cssSelector("input[placeholder='Mật khẩu']")).sendKeys("123456789");
		driver.findElement(By.id("web-login")).click();
		System.out.println("login successful");
		
//		search audio
		String keysearch = "nguyen";
		wait.until(ExpectedConditions.elementToBeClickable(By.id("search_transcript")));
		driver.findElement(By.id("search_transcript")).sendKeys(keysearch);
		Assert.assertEquals(driver.findElement(By.className("el-loading-text")).getText(), "Đang tải danh sách bản ghi.Vui lòng chờ...");
		wait.until(ExpectedConditions.invisibilityOf(driver.findElement(By.xpath("//p[@class='el-loading-text']"))));
//		Thread.sleep(5000);
		String audioName1 = driver.findElement(By.xpath("(//div[@class='audio_title'])[1]")).getText();
		String audioCovertName1 = Unidecode.decode(audioName1.toLowerCase());
		String audioName2 = driver.findElement(By.xpath("(//div[@class='audio_title'])[1]")).getText();
		String audioConvertName2 = Unidecode.decode(audioName2.toLowerCase());
		Assert.assertTrue(audioCovertName1.contains(keysearch));
		Assert.assertTrue(audioConvertName2.contains(keysearch));
		System.out.println("Done check audio name contains key search");
		
//		Go to audio's documents
		WebElement audioLink = driver.findElement(By.xpath("//div[@class='audio_title' and contains(text(),'nguyen-tac-bau-cu')]"));
		audioLink.click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='audio_title' and contains(text(),'nguyen-tac-bau-cu')]")));
		Thread.sleep(5000);
		
//		Add text into document
		WebElement editText = driver.findElement(By.xpath("(//span[@class='text' and contains(text(),'dân')])[1]"));
		editText.sendKeys("\n today is very beautiful \n");
		
		String desiredText = "today is very beautiful";

		// Execute JavaScript to search for the desired text within the page
		JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; // cast the WebDriver instance to a JSExecutor -> allow to execute JS code in current page
		String innerText = jsExecutor.executeScript("return document.documentElement.innerText;").toString();
//      System.out.println(innerText);
		Assert.assertTrue(innerText.contains(desiredText));
		System.out.println("The text is presented on the screen");
		
//		Delete text
		String deleteText = "today is very beautiful";
		WebElement element = driver.findElement(By.xpath("//span[@class='text' and contains(text(),'today')]"));
		element.sendKeys(Keys.CONTROL + "a");
	    element.sendKeys(Keys.DELETE);
		
//		String[] words = deleteText.split(" ");
//		for (String word : words) {
//			System.out.println(word);
//		}
//		
//		List<String> newList = new ArrayList<>();
//        for (String searchText : words) {
//            // Construct the XPath expression using the contains() function with the desired text
//            String xpathExpression = "//span[@class='text' and contains(text(), '" + searchText + "')]";
//            newList.add(xpathExpression);
//            System.out.println(xpathExpression);
//        }
//        
//        for (String location : newList) {
//            WebElement element = driver.findElement(By.xpath(location));
//            element.clear();
//        }

}
}