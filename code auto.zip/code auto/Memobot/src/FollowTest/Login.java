package FollowTest;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.Assert;

import me.xuender.unidecode.Unidecode;
//GroudId's name is optional
//artifactId's name is "selenium-java" 
public class Login {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		ChromeOptions co = new ChromeOptions();
		co.addArguments("--remote-allow-origins=*");
		System.setProperty("webdriver.chrome.driver", "/Users/admin/Downloads/chromedriver/chromedriver-win64/chromedriver.exe");
		WebDriver driver = new ChromeDriver(co);
		driver.get("https://memobot.io/");
		Thread.sleep(1000);
		Assert.assertEquals(driver.getTitle(), "Memobot - Trợ lý giọng nói của bạn mọi lúc, mọi nơi");
		driver.findElement(By.id("sign-in")).click();
		Thread.sleep(3000);
		Assert.assertEquals(driver.getCurrentUrl(), "https://app.memobot.io/dang-nhap");
		System.out.println("done enter website");
		
		String email = "nguyenthuhoa712@gmail.com";
		String wrongPass = "12345678910";
		String truePass = "123456789";
//		login with blank email and blank password
		Thread.sleep(3000);
		driver.findElement(By.id("web-login")).click();
		Thread.sleep(3000);
		String emailExpectText = "Email nhập chưa đúng";
		String passwordExpectText = "Mật khẩu không ít hơn 6 ký tự";
		String emailResultText = driver.findElement(By.xpath("//div[@class='el-form-item is-error is-required']//div[@class='el-form-item__content']")).getText();
		String passwordResultText = driver.findElement(By.xpath("//div[@class='el-form-item el-tooltip is-error is-required']//div[@class='el-form-item__content']")).getText();
		Assert.assertEquals(emailResultText, emailExpectText);
		Assert.assertEquals(passwordResultText, passwordExpectText);
		System.out.println("done test blank email and blank password");
		
//		login unsuccessfully with wrong account
		driver.findElement(By.cssSelector("input[placeholder='Email']")).sendKeys(email);
		driver.findElement(By.xpath("//input[@placeholder='Mật khẩu']")).sendKeys(wrongPass);
		driver.findElement(By.id("web-login")).click();
		Thread.sleep(1000);
		Assert.assertEquals(driver.findElement(By.cssSelector("div[role='alert']")).getText(), "You have entered wrong login information");
		System.out.println("done test wrong account");
		
//		login successful
		driver.findElement(By.cssSelector("input[placeholder='Email']")).clear();
		driver.findElement(By.cssSelector("input[placeholder='Mật khẩu']")).clear();
		driver.findElement(By.cssSelector("input[placeholder='Email']")).sendKeys(email);
		driver.findElement(By.cssSelector("input[placeholder='Mật khẩu']")).sendKeys(truePass);
		driver.findElement(By.id("web-login")).click();
		System.out.println("login successful");
		Thread.sleep(5000);
		String userName = driver.findElement(By.cssSelector("div[class='user_info_menu'] > div:nth-child(2) > div:nth-child(1) > span")).getText();
		System.out.println(userName);
		Assert.assertEquals(userName, "Thu Hòa Nguyễn");
		
	}

}
