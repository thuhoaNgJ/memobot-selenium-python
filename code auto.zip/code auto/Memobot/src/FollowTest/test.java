package FollowTest;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import me.xuender.unidecode.Unidecode;

public class test {

	public static void main(String[] args) {
		ChromeOptions co = new ChromeOptions();
		co.addArguments("--remote-allow-origins=*");
		System.setProperty("webdriver.chrome.driver", "/Users/admin/Downloads/chromedriver/chromedriver-win64/chromedriver.exe");
		WebDriver driver = new ChromeDriver(co);
		driver.get("https://memobot.io/");
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("sign-in")));
		
//		Test login
		driver.findElement(By.id("sign-in")).click();
		wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector("input[placeholder='Email']")));
		driver.findElement(By.cssSelector("input[placeholder='Email']")).sendKeys("nguyenthuhoa712@gmail.com");
		driver.findElement(By.cssSelector("input[placeholder='Mật khẩu']")).sendKeys("123456789");
		driver.findElement(By.id("web-login")).click();
		System.out.println("login successful");
		
//		Search audio
		String keysearch = "nguyen";
		wait.until(ExpectedConditions.elementToBeClickable(By.id("search_transcript")));
		driver.findElement(By.id("search_transcript")).sendKeys(keysearch);
		Assert.assertEquals(driver.findElement(By.className("el-loading-text")).getText(), "Đang tải danh sách bản ghi.Vui lòng chờ...");
		wait.until(ExpectedConditions.invisibilityOf(driver.findElement(By.xpath("//p[@class='el-loading-text']"))));
//		Go to audio's documents
//		wait.until(ExpectedConditions.elementToBeClickable(By.id("search_transcript")));
		WebElement audioLink = driver.findElement(By.xpath("//div[@class='audio_title' and contains(text(),'nguyen-tac-bau-cu')]"));
		audioLink.click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='audio_title' and contains(text(),'nguyen-tac-bau-cu')]")));
//		Thread.sleep(5000);
		
//		Delete text
		String deleteText = "Hôm nay tôi đi học";
		String[] words = deleteText.split(" ");
		for (String word : words) {
			System.out.println(word);
		}

	}

}
