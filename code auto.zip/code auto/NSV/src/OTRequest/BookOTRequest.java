/* *** NOTE: clear all request before running test case
Test case:
1. Check default date and time on booking OT form
2. Check create OT request fail with blank reason 
3. Check create OT request fail with start time = end time
4. Check create OT request with expire date
5. Check create OT request successfully -> check request is presented on Chờ duyệt screen
6. Check send report -> check text report is presented on screen
7. Check cancel OT request -> check request is transfer from Chờ duyệt to Đã hủy screen
*/
package OTRequest;

import java.time.Duration;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Collections;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import test.Login;

public class BookOTRequest {

	public WebDriver driver;
	private WebDriverWait wait;
	private JavascriptExecutor js;

	// components on Book OT popup
	String reasonTextboxLocator = "//textarea[@placeholder='Nhập lý do']";
	String dateLocator = "document.querySelectorAll('ion-datetime-button')[0].shadowRoot.querySelector('slot')";
	String startTimeLocator = "document.querySelectorAll('ion-datetime-button')[1].shadowRoot.querySelector('slot')";
	String endTimeLocator = "document.querySelectorAll('ion-datetime-button')[2].shadowRoot.querySelector('slot')";
	String clickBookOTBtn = "document.querySelector('ion-button.button-custom').click()"; // button Đặt lịch
	String clickOverlayLocator = "document.querySelector('[class=\"ion-datetime-button-overlay md modal-default show-modal\"]').shadowRoot.querySelector('ion-backdrop').click()";
	String clickChooseMonthAndYearBox = "document.querySelector('ion-datetime[id=\"time\"]').shadowRoot.querySelector('.calendar-month-year').querySelector('ion-label').click()";

	public static void main(String[] args) throws InterruptedException {
		BookOTRequest bookOT = new BookOTRequest();

		bookOT.checkDefaultDateTime();
		bookOT.bookOTFailWithBlankReason();
		bookOT.bookOTFailWithWrongTime();
		bookOT.bookOTWithExpireTime("05-11-2023", "20:00", "21:00");

		String day1 = "30-11-2023";
		String startTime1 = "20:00";
		String endTime1 = "20:30";
		bookOT.bookOTRequest(day1, startTime1, endTime1); // book request
		bookOT.checkListRequest(day1, startTime1, endTime1); // check if request is presented on Chờ duyệt screen
		Integer requestIndex1 = bookOT.getIndexOfRequest(day1, startTime1, endTime1);
		bookOT.cancelRequest(requestIndex1);
		
		String day2 = "28-11-2023";
		String startTime2 = "21:00";
		String endTime2 = "23:00";
		String report2 = "Báo cáo công việc đã làm OT";
		bookOT.bookOTRequest(day2, startTime2, endTime2); // book request
		bookOT.checkListRequest(day2, startTime2, endTime2); // check if request is presented on Chờ duyệt screen
		Integer requestIndex2 = bookOT.getIndexOfRequest(day2, startTime2, endTime2);
		bookOT.sendReport(requestIndex2, report2); // send report
		
		String day3 = "29-11-2023";
		String startTime3 = "20:00";
		String endTime3 = "20:30";
		String report3 = "Báo cáo công việc đã làm OT";
		bookOT.bookOTRequest(day3, startTime3, endTime3); // book request
		Integer requestIndex3 = bookOT.getIndexOfRequest(day3, startTime3, endTime3);
		bookOT.sendReport(requestIndex3, report3); // send report
	}

	public BookOTRequest() {
		Login login = new Login();
		login.setup();
		login.performLogin("user5@vais.vn", "dev@12345", "userTest5");
		this.driver = login.getDriver();
		wait = new WebDriverWait(driver, Duration.ofSeconds(20));
		js = (JavascriptExecutor) driver;
	}

	public void openBookingForm() {
		boolean isTextPresent = driver.getPageSource().contains("Đặt lịch làm ngoài giờ");
		if (isTextPresent == false) {
			driver.get("https://nhansu-fe-dev.vais.vn");
			wait.until(ExpectedConditions.textToBePresentInElementLocated(By.xpath("//h3[@class='header-name']"),
					"Xin chào"));
			WebElement calendarBtn = driver.findElement(By.xpath("//ion-label[contains(text(),'Lịch')]"));
			calendarBtn.click();
			wait.until(ExpectedConditions
					.visibilityOfElementLocated(By.xpath("//ion-label[contains(text(),'Đăng ký lịch')]")));
			driver.findElement(By.xpath("//span[contains(text(),'Làm thêm giờ')]")).click();
			wait.until(ExpectedConditions
					.visibilityOfElementLocated(By.xpath("//ion-title[contains(text(),'Đặt lịch làm ngoài giờ')]")));
		}
	}

	public void openListRequestForm() throws InterruptedException {
		boolean isTextPresent = driver.getPageSource().contains("Trạng thái phê duyệt");
		if (isTextPresent == false) {
			driver.get("https://nhansu-fe-dev.vais.vn");
			wait.until(ExpectedConditions.textToBePresentInElementLocated(By.xpath("//h3[@class='header-name']"),
					"Xin chào"));
			WebElement requestBtn = driver.findElement(By.xpath("//ion-label[contains(text(),'Phê duyệt')]"));
			requestBtn.click();
			Thread.sleep(3000);
		}
	}

	public void checkDefaultDateTime() {
		openBookingForm();

		// check default default date is the current date
		LocalDateTime dateNow = LocalDateTime.now();
		DateTimeFormatter formatterDate = DateTimeFormatter.ofPattern("dd 'thg' MM, yyyy");
		String formattedDate = dateNow.format(formatterDate);

		String defaultDate = (String) js.executeScript("return " + dateLocator + ".textContent");
		Assert.assertTrue(defaultDate.contains(formattedDate));

		// check default start time and end time is the current time
		LocalDateTime timeNow = LocalDateTime.now();
		DateTimeFormatter formatterTime = DateTimeFormatter.ofPattern("HH:mm");
		String formattedTime = timeNow.format(formatterTime);

		String startTime = (String) js.executeScript("return " + startTimeLocator + ".textContent");
		String endTime = (String) js.executeScript("return " + endTimeLocator + ".textContent");

		Assert.assertTrue(startTime.contains(formattedTime) && endTime.contains(formattedTime));

		System.out.println("CHECK DONE DEFAULT DATE AND TIME.");
	}

	public void bookOTFailWithBlankReason() {
		// check validation cannot blank reason textbox
		openBookingForm();
		js.executeScript(clickBookOTBtn);
		String reasonValid = driver.findElement(By.xpath("//ion-label[@color='danger']")).getText();
		Assert.assertTrue(reasonValid.contains("Lý do không được để trống"));

		// check validation is disable after filing reason textbox
		WebElement reasonTextbox = driver.findElement(By.xpath("//textarea[@placeholder='Nhập lý do']"));
		reasonTextbox.sendKeys("Test lý do OT");
		js.executeScript(clickBookOTBtn);
		boolean isReasonValidPresent = driver.getPageSource().contains(reasonValid);
		Assert.assertFalse(isReasonValidPresent);
		System.out.println("CHECK DONE CANNOT CREATE ot WITH NO REASON");
	}

	public void bookOTFailWithWrongTime() {
		openBookingForm();
		js.executeScript(clickBookOTBtn);

		String TimeValid = driver.findElement(By.xpath("//ion-label[@color='danger']")).getText();
		Assert.assertTrue(TimeValid.contains("Thời gian làm việc không nhỏ hơn 0"));

		System.out.println("CHECK DONE CANNOT CREATE OT WITH START DATE = END DATE");
	}

	public void bookOTWithExpireTime(String bookOTDay, String startOTTime, String endOTTime)
			throws InterruptedException {
		bookOTRequest(bookOTDay, startOTTime, endOTTime);
		openListRequestForm();
		Integer requestIndex = getIndexOfRequest(bookOTDay, startOTTime, endOTTime);
		List<WebElement> statusChip = driver.findElements(By.xpath("//ion-card//ion-row[1]//ion-chip"));
		Assert.assertTrue(statusChip.get(requestIndex).getText().contains("Hết hạn"));
		System.out.println("done");
	}

	public void bookOTRequest(String bookOTDay, String startOTTime, String endOTTime) throws InterruptedException {
		openBookingForm();
		js.executeScript(clickBookOTBtn);
		// Add OT reason
		driver.findElement(By.xpath(reasonTextboxLocator)).sendKeys("Test lý do OT");

		String[] dayArr = bookOTDay.split("-");
		Integer bookingDay = Integer.parseInt(dayArr[0]);
		Integer bookingMonth = Integer.parseInt(dayArr[1]);
		Integer bookingYear = Integer.parseInt(dayArr[2]);

		String[] startTimeArr = startOTTime.split(":");
		Integer startHour = Integer.parseInt(startTimeArr[0]);
		Integer startMinute = Integer.parseInt(startTimeArr[1]);

		String[] endTimeArr = endOTTime.split(":");
		Integer endHour = Integer.parseInt(endTimeArr[0]);
		Integer endMinute = Integer.parseInt(endTimeArr[1]);

		// CHOOSE DAY
		js.executeScript(dateLocator + ".click()"); // open calendar

		js.executeScript(clickChooseMonthAndYearBox);
		js.executeScript(
				"document.querySelector('ion-datetime#time').shadowRoot.querySelector('[class=\"month-column ion-color ion-color-primary md\"]').shadowRoot.querySelector('[data-value=\""
						+ bookingMonth + "\"').click()");
		js.executeScript(
				"document.querySelector('ion-datetime#time').shadowRoot.querySelector('[class=\"year-column ion-color ion-color-primary md\"]').shadowRoot.querySelector('[data-value=\""
						+ bookingYear + "\"').click()");
		js.executeScript(clickChooseMonthAndYearBox);

		js.executeScript(
				"document.querySelector('ion-datetime[id=\"time\"]').shadowRoot.querySelectorAll('.calendar-month-grid')[1].querySelector('[data-day=\""
						+ bookingDay + "\"]').click()");
		js.executeScript(clickOverlayLocator); // close calendar

		// CHOOSE START TIME
		js.executeScript(startTimeLocator + ".click()");
		js.executeScript(
				"document.querySelector('ion-datetime#fromDate').shadowRoot.querySelectorAll('ion-picker-column-internal')[0].shadowRoot.querySelector('[data-value=\""
						+ startHour + "\"').click()");
		Thread.sleep(1000);
		js.executeScript(
				"document.querySelector('ion-datetime#fromDate').shadowRoot.querySelectorAll('ion-picker-column-internal')[1].shadowRoot.querySelector('[data-value=\""
						+ startMinute + "\"').click()");
		Thread.sleep(1000);
		js.executeScript(clickOverlayLocator); // close scroll time-picker

		// CHOOSE END TIME
		js.executeScript(endTimeLocator + ".click()");
		js.executeScript(
				"document.querySelector('ion-datetime#toDate').shadowRoot.querySelectorAll('ion-picker-column-internal')[0].shadowRoot.querySelector('[data-value=\""
						+ endHour + "\"').click()");
		Thread.sleep(1000);
		js.executeScript(
				"document.querySelector('ion-datetime#toDate').shadowRoot.querySelectorAll('ion-picker-column-internal')[1].shadowRoot.querySelector('[data-value=\""
						+ endMinute + "\"').click()");
		Thread.sleep(1000);
		js.executeScript(clickOverlayLocator); // close scroll time-picker

		// CLICK BUTTON ĐẶT LỊCH
		js.executeScript(clickBookOTBtn);
	}

	public int getIndexOfRequest(String bookOTDay, String startOTTime, String endOTTime) {
		String OTTimeString = startOTTime + " - " + endOTTime;
		List<WebElement> OTDayText = driver.findElements(By.xpath("//ion-card-content//ion-label//span[1]"));
		List<WebElement> OTTimeText = driver.findElements(By.xpath("//ion-card-content//ion-label//span[2]"));

		boolean isRequestPresent = false;
		int requestIndex = 0;
		for (int i = 0; i < OTDayText.size(); i++) {
			String day = OTDayText.get(i).getText();
			String time = OTTimeText.get(i).getText();
			if (day.contains(bookOTDay) && time.contains(OTTimeString)) {
				requestIndex = i;
				isRequestPresent = true;
				System.out.println("Request OT on " + day + " on " + time + " is presented on Chờ duyệt screen.");
				break;
			}
		}
		return requestIndex;
	}

	public void checkListRequest(String bookOTDay, String startOTTime, String endOTTime) throws InterruptedException {
		openListRequestForm();
		boolean isDayPresent = driver.getPageSource().contains(bookOTDay);
		boolean isTimePresent = driver.getPageSource().contains(startOTTime + " - " + endOTTime);
		if (isDayPresent == true && isTimePresent == true) {
			System.out.println("Request is present on Chờ duyệt screen.");
		} else {
			System.out.println("Request is not present on Chờ duyệt screen.");
		}
	}

	public void sendReport(int requestIndex, String reportContent) throws InterruptedException {
		openListRequestForm();

		List<WebElement> sendReportBtns = driver.findElements(By.xpath("//span[contains(text(),'Báo cáo')]"));
		sendReportBtns.get(requestIndex).click();
		wait.until(ExpectedConditions
				.visibilityOfElementLocated(By.xpath("//textarea[@placeholder='Nhập công việc đã làm']")));
		driver.findElement(By.xpath("//textarea[@placeholder='Nhập công việc đã làm']")).sendKeys(reportContent);
		WebElement reportConfirmBtn = driver
				.findElement(By.cssSelector("ion-button[class*='md button button-clear button-strong']"));
		reportConfirmBtn.click();
		Thread.sleep(2000);

		boolean isTextPresent = driver.getPageSource().contains(reportContent);
		if (isTextPresent == true) {
			System.out.println("Send report successfully.");
		}
	}

	public void cancelRequest(int requestIndex) throws InterruptedException {
		openListRequestForm();
		List<WebElement> OTDayText = driver.findElements(By.xpath("//ion-card-content//ion-label//span[1]"));
		List<WebElement> OTTimeText = driver.findElements(By.xpath("//ion-card-content//ion-label//span[2]"));

		String OTDay = OTDayText.get(requestIndex).getText();
		String OTTime = OTTimeText.get(requestIndex).getText();

		List<WebElement> cancelReportBtns = driver.findElements(By.xpath("//ion-button[contains(text(),'Hủy')]"));
		cancelReportBtns.get(requestIndex).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[.='Xác nhận hủy sự kiện ']")));
		driver.findElement(By.xpath("//span[.='OK']")).click();
		wait.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath("//div[.='Xác nhận hủy sự kiện ']")));

		boolean isDayPresentReview = driver.getPageSource().contains(OTDay);
		boolean isTimePresentReview = driver.getPageSource().contains(OTTime);
		Assert.assertFalse(isDayPresentReview);
		Assert.assertFalse(isTimePresentReview);

		driver.findElement(By.xpath("//ion-segment-button[.='Đã hủy']")).click();
		Thread.sleep(3000);

		boolean isDayPresentCancel = driver.getPageSource().contains(OTDay);
		boolean isTimePresentCancel = driver.getPageSource().contains(OTTime);
		Assert.assertTrue(isDayPresentCancel);
		Assert.assertTrue(isTimePresentCancel);
		if (isDayPresentCancel == true && isTimePresentCancel == true) {
			System.out.println("Request is presented on Đã hủy screen.");
		}
		List<WebElement> statusChip = driver.findElements(By.xpath("//ion-card//ion-row[1]//ion-chip"));

		for (int i = 0; i < statusChip.size(); i++) {
			statusChip.get(i).getText().contains("Đã hủy");
		}
	}

}
