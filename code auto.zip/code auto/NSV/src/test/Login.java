package test;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

public class Login {

	    private WebDriver driver;
	    private WebDriverWait wait;

	    public static void main(String[] args) throws InterruptedException {
	        Login login = new Login();
	        login.setup();
	        login.performLogout();
	        login.performLogin("user5@vais.vn", "dev@12345", "userTest5");
	        login.performLogout();
	    }
	    
	    public WebDriver getDriver() {
	    	return driver;
	    }

	    public void setup() {
	        ChromeOptions co = new ChromeOptions();
	        co.addArguments("--remote-allow-origins=*");
	        System.setProperty("webdriver.chrome.driver", "/Users/admin/Downloads/chromedriver/chromedriver-win64/chromedriver.exe");
	        driver = new ChromeDriver(co);
	        wait = new WebDriverWait(driver, Duration.ofSeconds(20));
	        driver.get("https://nhansu-fe-dev.vais.vn");
	        JavascriptExecutor js = (JavascriptExecutor) driver;
//			Specify the desired width and height
			Dimension windowSize = new Dimension(390, 844);
			driver.manage().window().setSize(windowSize);
	    }

	    public void performLogin(String email, String password, String userName) {
	        WebElement emailField = driver.findElement(By.cssSelector("input[type='email']"));
	        WebElement passField = driver.findElement(By.cssSelector("input[type='password']"));

	        emailField.sendKeys(email);
	        passField.sendKeys(password);
	        passField.sendKeys(Keys.ENTER);

	        wait.until(ExpectedConditions.textToBePresentInElementLocated(By.xpath("//h3[@class='header-name']"), "Xin chào"));

	        String actualUserName = driver.findElement(By.xpath("//span[@class='header-name-title']")).getText();
	        Assert.assertEquals(actualUserName, userName);
	        System.out.println("Done login"); 
	    }
	    
	    public void performLogout() throws InterruptedException
	    {
	    	driver.get("https://nhansu-fe-dev.vais.vn");
	    	Thread.sleep(2000);
	    	boolean isLoginPresent = driver.getPageSource().contains("Đăng nhập ");
	    	if (isLoginPresent == true)
	    	{
	    		System.out.println("You're already logout.");
	    	}else
	    	{
				WebElement requestBtn = driver.findElement(By.xpath("//ion-label[contains(text(),'Cá nhân')]"));
				requestBtn.click();
				Thread.sleep(2000);
				driver.findElement(By.xpath("//ion-button[.=' Đăng xuất ']")).click();
				wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[.='Bạn có chắc chắn?']")));
				driver.findElement(By.xpath("//button//span[.='OK']")).click();
				Thread.sleep(1000);
				boolean isLoginPresentText = driver.getPageSource().contains("Đăng nhập ");
				Assert.assertTrue(isLoginPresentText);
	    	}
	    
	    }

}
