/*
 * Write script to check function: checkin, checkout, forget checkin, delete checkin
 * Steps: checkin -> delete checkin -> forget checkin -> checkout 
 */

package test;

import java.time.Duration;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

public class CheckInOut {

	public static WebDriver driver;
	private WebDriverWait wait;
	private JavascriptExecutor js;

	public List<WebElement> checkinTime1;
	public List<WebElement> checkoutTime1;
	public WebElement homeBtn;
	public WebElement checkinBtn;
	public WebElement calendarBtn;

	public static void main(String[] args) throws InterruptedException {
		CheckInOut checkin = new CheckInOut();
		checkin.checkin();
		checkin.deleteCheckIn();
		checkin.forgetCheckIn("8","45"); // form: ("h","m")
		checkin.checkout();
	}

	public CheckInOut() {
		Login login = new Login();
		login.setup();
		login.performLogin("user5@vais.vn", "dev@12345", "userTest5");
		this.driver = login.getDriver();
		wait = new WebDriverWait(driver, Duration.ofSeconds(20));
		js = (JavascriptExecutor) driver;
	}

	public void performCheckTime() throws InterruptedException {
		homeBtn = driver.findElement(By.xpath("//ion-label[contains(text(),'Trang chủ')]"));
		homeBtn.click();
		Thread.sleep(3000);

		js.executeScript("document.querySelector('ion-fab-button').shadowRoot.querySelector('.button-native').click()"); // click
																															// button
																															// checkin,out
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h2[contains(text(),'Xác nhận')]")));
		Assert.assertTrue(driver.findElement(By.xpath("//div[@class='alert-message sc-ion-alert-md']")).getText()
				.contains("Bạn có chắc chắn"));
		driver.findElement(By.xpath("//span[normalize-space()='OK']")).click();
		wait.until(ExpectedConditions.invisibilityOfElementWithText(By.tagName("ion-loading"), "Vui lòng chờ"));
		Thread.sleep(3000);
	}

	public String getFormattedTime() {
		LocalDateTime now = LocalDateTime.now();
		DateTimeFormatter formatterTime1 = DateTimeFormatter.ofPattern("HH:mm");
		String formattedTime1 = now.format(formatterTime1);
		System.out.println("Current Time: " + formattedTime1);

		LocalDateTime nowAdd = LocalDateTime.now();
		LocalDateTime Add1Min = nowAdd.plusMinutes(1);
		String formattedTimeAddOneMinute = Add1Min.format(formatterTime1);

		LocalDateTime nowSubtract = LocalDateTime.now();
		LocalDateTime Subtract1Min = nowSubtract.minusMinutes(1);
		String formattedTimeSubtractOneMinute = Subtract1Min.format(formatterTime1);

		String listCheckTime = formattedTimeSubtractOneMinute + ", " + formattedTime1 + ", "
				+ formattedTimeAddOneMinute;
		return listCheckTime;
	}

	public void checkin() throws InterruptedException {
		Thread.sleep(3000);
		checkinBtn = driver.findElement(By.tagName("ion-fab-button")).findElement(By.tagName("ion-label"));
		Assert.assertEquals(checkinBtn.getText(), "Vào");
		System.out.println("The Btn default text is 'Vào'");
		performCheckTime();

		Assert.assertEquals(checkinBtn.getText(), "Ra");
		System.out.println("The Btn's text is changed to 'Ra' after checking");

		checkinTime1 = driver.findElements(By.cssSelector(
				"div[class='checkin flex-1 flex items-center justify-center space-x-2'] span[class='time-log-text']"));
		String listCheckTime = getFormattedTime();
		Assert.assertTrue(listCheckTime.contains(checkinTime1.get(0).getText()));
	}

	public void checkout() throws InterruptedException {
		Thread.sleep(3000);
		checkinBtn = driver.findElement(By.tagName("ion-fab-button")).findElement(By.tagName("ion-label"));
		Assert.assertEquals(checkinBtn.getText(), "Ra");
		System.out.println("The Btn default text is 'Ra'");
		performCheckTime();

		Assert.assertEquals(checkinBtn.getText(), "Vào");
		System.out.println("The Btn's text is changed to 'Vào' after checking");

		checkoutTime1 = driver.findElements(By.cssSelector(
				"div[class='checkout flex-1 flex items-center justify-center space-x-2'] span[class='time-log-text']"));
		String listCheckTime = getFormattedTime();
		Assert.assertTrue(listCheckTime.contains(checkoutTime1.get(0).getText()));
	}

	public void deleteCheckIn() throws InterruptedException {
		// create list button to checkin, out
		Thread.sleep(3000);
		List<WebElement> deleteBtns = driver
				.findElements(By.cssSelector("ion-button[class*='ion-color ion-color-danger md button']"));

		deleteBtns.get(0).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h2[contains(text(),'Xác nhận')]")));
		// Check time which is presented on the delete check-in time alert
		String textAlertDeleteTime = driver.findElement(By.cssSelector("div[class$='alert-message sc-ion-alert-md']"))
				.getText();

		Assert.assertTrue(textAlertDeleteTime.contains(checkinTime1.get(0).getText()));
		// Confirm to delete time
		driver.findElement(By.cssSelector(
				"button[class*='alert-button ion-focusable ion-activatable alert-button-role-confirm sc-ion-alert-md']"))
				.click();
		wait.until(ExpectedConditions.invisibilityOfElementWithText(By.tagName("ion-loading"), "Vui lòng chờ"));
		// wait until check-in time is deleted
		boolean isDisplayed = wait.until(ExpectedConditions.invisibilityOf(checkinTime1.get(0)));
		Assert.assertTrue(isDisplayed);

		// Check Btn is changed to "Vào" after deleting the check-in time
		Assert.assertEquals(checkinBtn.getText(), "Vào");
		System.out.println("The Btn's text is changed to 'Vào' after deleting checking");

		System.out.println("Delete check-in time sucessfully");
	}

	public void forgetCheckIn(String checkHour, String checkMinute) throws InterruptedException {
		calendarBtn = driver.findElement(By.xpath("//ion-label[contains(text(),'Lịch')]"));
		calendarBtn.click();
		wait.until(ExpectedConditions
				.visibilityOfElementLocated(By.xpath("//ion-label[contains(text(),'Đăng ký lịch')]")));

		driver.findElement(By.xpath("//span[contains(text(),'Quên chấm công')]")).click();
		wait.until(ExpectedConditions
				.visibilityOfElementLocated(By.xpath("//ion-title[contains(text(),'Đặt lịch quên chấm công')]")));

		// Check default day is the current day
		String defaultForgetCheckDay = js.executeScript(
				"return document.querySelectorAll('ion-datetime-button')[0].shadowRoot.querySelector('button').querySelector('slot').textContent")
				.toString();
		System.out.println(defaultForgetCheckDay);

		LocalDateTime now1 = LocalDateTime.now();
		DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("d 'thg' M, yyyy");
		String calendarFormattedDate = now1.format(dateFormatter);
		Assert.assertEquals(defaultForgetCheckDay, calendarFormattedDate);
		System.out.println("Check done default day is the current day.");

		// Check default time is the current time
		String defaultForgetCheckTime = js.executeScript(
				"return document.querySelectorAll('ion-datetime-button')[1].shadowRoot.querySelector('button').querySelector('slot').textContent")
				.toString();

		LocalDateTime now2 = LocalDateTime.now();

		DateTimeFormatter timeFormatter = DateTimeFormatter.ofPattern("HH:mm");
		String calendarFormattedTime = now2.format(timeFormatter);
		Assert.assertEquals(defaultForgetCheckTime, calendarFormattedTime);
		System.out.println("Check done default time is the current time.");

		// Choose checkin time 08:45
		WebElement chooseTimeBtn = driver.findElement(By.xpath("(//ion-datetime-button)[2]"));
		chooseTimeBtn.click();

		js.executeScript(
				"document.querySelector('ion-datetime#time').shadowRoot.querySelector('.datetime-time').querySelector('ion-picker-internal') "
						+ ".querySelectorAll('ion-picker-column-internal')[0].shadowRoot.querySelector('button[data-value=\""
						+ checkHour + "\"]').click()");
		Thread.sleep(3000);
		js.executeScript(
				"document.querySelector('ion-datetime#time').shadowRoot.querySelector('.datetime-time').querySelector('ion-picker-internal') "
						+ ".querySelectorAll('ion-picker-column-internal')[1].shadowRoot.querySelector('button[data-value=\""
						+ checkMinute + "\"]').click()");
		Thread.sleep(3000);

		// Create an instance of Actions class
		Actions actions = new Actions(driver);
 
		// Perform a click action at a specific location outside the popup
		actions.moveByOffset(0, 0).click().build().perform();
		WebElement forgetCheckinBtn = driver.findElement(By.xpath("(//ion-radio)[1]"));
		WebElement forgetCheckoutBtn = driver.findElement(By.xpath("(//ion-radio)[2]"));
		forgetCheckinBtn.click();

		// click button "Đặt lịch"
		js.executeScript("document.querySelector('[class*=\"ion-margin\"]').click()");
		Thread.sleep(3000);

		// check text of Checkin button is "Ra" after forgetting checkin
		checkinBtn = driver.findElement(By.tagName("ion-fab-button")).findElement(By.tagName("ion-label"));
		Assert.assertEquals(checkinBtn.getText(), "Ra");
		System.out.println("The Btn is from 'Vào' to 'Ra' after forgetting checkin sucessfully");

		// Back to Trang chủ to check forget checkin time
		homeBtn.click();
		Thread.sleep(3000);

		WebElement forgetCheckLocator = driver.findElement(By.cssSelector(
				"div[class='checkin flex-1 flex items-center justify-center space-x-2'] span[class='time-log-text']"));
		System.out.println("forget checkin time is: " + forgetCheckLocator.getText());

		LocalTime time = LocalTime.of(Integer.parseInt(checkHour), Integer.parseInt(checkMinute));
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("HH:mm");
		String formattedTime = time.format(formatter);
		System.out.println("Check done presenting forget checkin time on homePage");

	}

}