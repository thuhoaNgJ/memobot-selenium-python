package PaidLeaveRequest;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import test.Login;

public class BookPaidLeaveRequest {
	public WebDriver driver;
	private WebDriverWait wait;
	private JavascriptExecutor js;

	// Locator of button Đặt lịch
	String clickBookingBtn = "document.querySelector('.ion-margin.button-custom.ion-color.ion-color-tertiary.md.button.button-block.button-round.button-outline.ion-activatable.ion-focusable').shadowRoot.querySelector('.button-native').click()";

	public static void main(String[] args) throws InterruptedException {
		BookPaidLeaveRequest bookReq = new BookPaidLeaveRequest();
		bookReq.CreateRequestWithBlankField();
		bookReq.createPaidLeaveRequest("Test lý do nghỉ có lương", "06-12-2023", "Buổi sáng");
		bookReq.createPaidLeaveFailWithExistedTime("Test lý do nghỉ có lương", "06-12-2023", "sáng");
		Integer requestIndex1 = bookReq.getIndexOfPaidLeaveRequest("06-12-2023", "Buổi sáng");
		bookReq.checkCreatedStatusRequest("06-12-2023", "Buổi sáng");
		bookReq.cancelPaidLeaveRequest(requestIndex1, "06-12-2023", "Buổi sáng");
		
		// create request for leader review accept
		bookReq.createPaidLeaveRequest("Test lý do nghỉ có lương", "07-12-2023", "Buổi sáng");	
		bookReq.checkCreatedStatusRequest("07-12-2023", "Buổi sáng");
		
		// create request for leader review cancel
		bookReq.createPaidLeaveRequest("Test lý do nghỉ có lương", "07-12-2023", "Buổi chiều");	
		bookReq.checkCreatedStatusRequest("07-12-2023", "Buổi chiều");
	}

	public BookPaidLeaveRequest() {
		Login login = new Login();
		login.setup();
		login.performLogin("user5@vais.vn", "dev@12345", "userTest5");
		this.driver = login.getDriver();
		wait = new WebDriverWait(driver, Duration.ofSeconds(20));
		js = (JavascriptExecutor) driver;
	}

	public void openWfmForm() {
		boolean isTextPresent = driver.getPageSource().contains("Đặt lịch nghỉ có lương");
		if (isTextPresent == false) {
			driver.get("https://nhansu-fe-dev.vais.vn");
			wait.until(ExpectedConditions.textToBePresentInElementLocated(By.xpath("//h3[@class='header-name']"),
					"Xin chào"));
			WebElement calendarBtn = driver.findElement(By.xpath("//ion-label[contains(text(),'Lịch')]"));
			calendarBtn.click();
			wait.until(ExpectedConditions
					.visibilityOfElementLocated(By.xpath("//ion-label[contains(text(),'Đăng ký lịch')]")));
			driver.findElement(By.xpath("//span[contains(text(),'Nghỉ có lương')]")).click();
			wait.until(ExpectedConditions
					.visibilityOfElementLocated(By.xpath("//ion-title[contains(text(),'Đặt lịch nghỉ có lương')]")));
		}
	}

	public void CreateRequestWithBlankField() {
		openWfmForm();
		js.executeScript(clickBookingBtn);
		Assert.assertTrue(driver.getPageSource().contains("Lý do không được để trống"));
		Assert.assertTrue(driver.getPageSource().contains("Hãy chọn buổi trong ngày"));
		System.out.println("CHECK DONE CANNOT EMPTY BOOK WFH FIELD");
	}

	public void createPaidLeaveFailWithExistedTime(String reason, String paidLeaveDay, String paidLeaveTime)
			throws InterruptedException {
		WebElement requestBtn = driver.findElement(By.xpath("//ion-label[contains(text(),'Phê duyệt')]"));
		requestBtn.click();
		Thread.sleep(3000);
		String pageSourceText = driver.getPageSource();
		if (!pageSourceText.contains(paidLeaveDay) && !pageSourceText.contains(paidLeaveTime)) {
			createPaidLeaveRequest(reason, paidLeaveDay, paidLeaveTime);
		}
		createPaidLeaveRequest(reason, paidLeaveDay, paidLeaveTime);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h2[contains(text(),'Có lỗi xảy ra')]")));
		String text = driver.findElement(By.xpath("//div[@class='alert-message sc-ion-alert-md']")).getText();
		Assert.assertTrue(text.contains("Không được book trùng lịch"));
		System.out.println("CHECK DONE CANNOT CREATE REQUEST WITH EXIST TIME.");
	}

	public void createPaidLeaveRequest(String reason, String paidLeaveDay, String paidLeaveTime)
			throws InterruptedException {
		openWfmForm();

		String[] dayArr = paidLeaveDay.split("-");
		Integer bookingDay = Integer.parseInt(dayArr[0]);
		Integer bookingMonth = Integer.parseInt(dayArr[1]);
		Integer bookingYear = Integer.parseInt(dayArr[2]);

		String clickChooseMonthAndYearBox = "document.querySelector('[class*=\"datetime-presentation-date\"]').shadowRoot.querySelector('[class = \"calendar-month-year\"]').querySelector(\"ion-label\").click()";
		String clickChooseTimeBox = "document.querySelector('[class*=\"md in-item has-placeholder\"]').shadowRoot.querySelector('.select-wrapper').querySelector('.native-wrapper').querySelector('[part=\"placeholder\"]').click()";
		String clickOverLay = "document.querySelector('[class=\"date-picker bottom-end md modal-default show-modal\"]').shadowRoot.querySelector('ion-backdrop').click()";

		// Add reason
		driver.findElement(By.cssSelector("textarea[placeholder='Nhập lý do']")).sendKeys(reason);

		// choose booking day
		driver.findElement(By.xpath("//ion-label[normalize-space()='Ngày:']")).click(); // open calendar box
		Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("ion-datetime")));
		js.executeScript(clickChooseMonthAndYearBox);
		Thread.sleep(2000);

		js.executeScript(
				"document.querySelector('ion-datetime').shadowRoot.querySelector('[class*=\"month-column\"]').shadowRoot.querySelector('[data-value=\""
						+ bookingMonth + "\"').click()");
		js.executeScript(
				"document.querySelector('ion-datetime').shadowRoot.querySelector('[class*=\"year-column\"]').shadowRoot.querySelector('[data-value=\""
						+ bookingYear + "\"').click()");
		js.executeScript(clickChooseMonthAndYearBox);
		Thread.sleep(1000);
		js.executeScript(
				"document.querySelector('[class*=\"datetime-presentation-date\"]').shadowRoot.querySelector('.datetime-calendar').querySelector('.calendar-body.ion-focusable')"
						+ ".querySelector('.calendar-month:nth-child(2)').querySelector('[data-day=\"" + bookingDay
						+ "\"]').click()");
		js.executeScript(clickOverLay);
		Thread.sleep(1000);

		// choose booking time: Buổi sáng / Buổi chiều
		js.executeScript(clickChooseTimeBox);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'Buổi sáng')]")));
		driver.findElement(By.xpath("//div[contains(text(),'" + paidLeaveTime + "')]")).click();
		driver.findElement(By.xpath("//span[normalize-space()='OK']")).click();
		js.executeScript(clickBookingBtn);
		Thread.sleep(3000);
	}
	
	public void checkCreatedStatusRequest(String paidLeaveDay, String paidLeaveTime) throws InterruptedException
	{
		openListRequestForm();
		Integer requestIndex = getIndexOfPaidLeaveRequest(paidLeaveDay, paidLeaveTime);
		if (requestIndex != null) {
			System.out.println("Create request successfully. Request is presented on Chờ duyệt screen.");
		}
		List<WebElement> statusChip = driver.findElements(By.xpath("//ion-card//ion-row[1]//ion-chip"));
		Assert.assertTrue(statusChip.get(requestIndex).getText().contains("Chờ duyệt"));
	}

	public void cancelPaidLeaveRequest(int requestIndex, String PaidLeaveDay, String PaidLeaveTime)
			throws InterruptedException {
		String requestText = PaidLeaveDay + PaidLeaveTime;

		openListRequestForm();
		List<WebElement> cancelBtn = driver.findElements(By.xpath("//ion-button[.=' Hủy ']"));
		cancelBtn.get(requestIndex).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[.='Xác nhận hủy sự kiện ']")));
		driver.findElement(By.xpath("//span[.='OK']")).click();
		wait.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath("//div[.='Xác nhận hủy sự kiện ']")));

		List<WebElement> reviewOTDayText = driver.findElements(By.xpath("//ion-card-content//ion-label//span[1]"));
		List<WebElement> reviewOTTimeText = driver.findElements(By.xpath("//ion-card-content//ion-label//span[2]"));

		if (reviewOTDayText.size() == 0) {
			System.out.println("Request is removed on Chờ duyệt screen.");
		} else {
			for (int i = 0; i < reviewOTDayText.size(); i++) {
				String presentText = reviewOTDayText.get(i).getText() + reviewOTTimeText.get(i).getText();
				boolean isRequestPresent = presentText.contains(requestText);
				if (isRequestPresent == false) {
					System.out.println("Request is removed on Chờ duyệt screen.");
				}
			}
		}

		driver.findElement(By.xpath("//ion-segment-button[.='Đã hủy']")).click();
		Thread.sleep(3000);

		List<WebElement> cancelOTDayText = driver.findElements(By.xpath("//ion-card-content//ion-label//span[1]"));
		List<WebElement> cancelOTTimeText = driver.findElements(By.xpath("//ion-card-content//ion-label//span[2]"));

		for (int i = 0; i < cancelOTDayText.size(); i++) {
			String presentText = cancelOTDayText.get(i).getText() + " " + cancelOTTimeText.get(i).getText();
			boolean isRequestPresent = presentText.contains(requestText);
			if (isRequestPresent == true) {
				System.out.println("Request is presented on Đã hủy screen.");
				break;
			}
		}

		Integer cancelRequestIndex = getIndexOfPaidLeaveRequest(PaidLeaveDay, PaidLeaveTime);
		List<WebElement> statusChip = driver.findElements(By.xpath("//ion-card//ion-row[1]//ion-chip"));
		Assert.assertTrue(statusChip.get(cancelRequestIndex).getText().contains("Đã hủy"));
	}

	public void openListRequestForm() throws InterruptedException {
		boolean isTextPresent = driver.getPageSource().contains("Trạng thái phê duyệt");
		if (isTextPresent == false) {
			driver.get("https://nhansu-fe-dev.vais.vn");
			wait.until(ExpectedConditions.textToBePresentInElementLocated(By.xpath("//h3[@class='header-name']"),
					"Xin chào"));
			Thread.sleep(2000);
			WebElement requestBtn = driver.findElement(By.xpath("//ion-label[contains(text(),'Phê duyệt')]"));
			requestBtn.click();
			Thread.sleep(3000);
		}
	}

	public int getIndexOfPaidLeaveRequest(String PaidLeaveDay, String PaidLeaveTime) {
		List<WebElement> requestTypeText = driver.findElements(By.xpath("//ion-label[contains(@class,'event-title')]"));
		List<WebElement> requestDayText = driver.findElements(By.xpath("//ion-card-content//ion-label//span[1]"));
		List<WebElement> requestTimeText = driver.findElements(By.xpath("//ion-card-content//ion-label//span[2]"));

		int requestIndex = 0;
		for (int i = 0; i < requestDayText.size(); i++) {
			String requestType = requestTypeText.get(i).getText();
			String requestDay = requestDayText.get(i).getText();
			String requestTime = requestTimeText.get(i).getText();
			if (requestType.contains("Nghỉ có lương") && requestDay.contains(PaidLeaveDay)
					&& requestTime.contains(PaidLeaveTime)) {
				requestIndex = i;
				break;
			}
		}
		return requestIndex;
	}

}
