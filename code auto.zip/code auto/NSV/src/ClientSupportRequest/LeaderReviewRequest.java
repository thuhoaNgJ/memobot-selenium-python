package ClientSupportRequest;

import java.time.Duration;
import java.util.Collections;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import test.Login;

public class LeaderReviewRequest {
	public WebDriver driver;
	private WebDriverWait wait;
	private JavascriptExecutor js;

	List<WebElement> createrReq;
	List<WebElement> nameReq;
	List<WebElement> dayReq;
	List<WebElement> timeReq;
	List<WebElement> acptButtons;
	List<WebElement> denyButtons;
	
	public static void main(String[] args) throws InterruptedException {
		LeaderReviewRequest reviewReq = new LeaderReviewRequest();
		reviewReq.openReviewReqPage();
		Integer requestIndex1 = reviewReq.getRequestIndex("userTest5", "Support khách hàng", "27-12-2023", "14:30", "18:30");
		reviewReq.acceptRequestWithReport(requestIndex1);
	}
	
	public LeaderReviewRequest() 
	{
		Login login = new Login();
		login.setup();
		login.performLogin("leader2@vais.vn", "dev@12345", "leader2");
		this.driver = login.getDriver();
		wait = new WebDriverWait(driver, Duration.ofSeconds(20));
		js = (JavascriptExecutor) driver;
	}
	
	public void openReviewReqPage() throws InterruptedException 
	{
		boolean isTextPresent = driver.getPageSource().contains("Quản lý phê duyệt");
		if (isTextPresent == false) {
			driver.get("https://nhansu-fe-dev.vais.vn");
			wait.until(ExpectedConditions.textToBePresentInElementLocated(By.xpath("//h3[@class='header-name']"), "Xin chào"));
			WebElement requestBtn = driver.findElement(By.xpath("//ion-label[contains(text(),'Phê duyệt')]"));
			requestBtn.click();
			Thread.sleep(3000);
			WebElement memberRequest = driver.findElement(By.xpath("//ion-button[contains(@class, 'md button button-clear')]"));
			memberRequest.click();
			Thread.sleep(3000);
		}
	}
	
	public int getRequestIndex(String username, String requestType, String OTDay, String startTime, String endTime) throws InterruptedException 
	{
		createrReq = driver.findElements(By.xpath("//ion-card//div//p//ion-label"));
		nameReq = driver.findElements(By.xpath("//ion-card//div//div//ion-card-content//div//ion-row[1]//ion-label"));
		dayReq = driver.findElements(By.xpath("//ion-card//div//div//ion-card-content//div//ion-row[2]//ion-label//span[1]"));
		timeReq = driver.findElements(By.xpath("//ion-card//div//div//ion-card-content//div//ion-row[2]//ion-label//span[2]"));
		acptButtons = driver.findElements(By.xpath("//ion-button[contains(text(),'Chấp thuận')]"));
		denyButtons = driver.findElements(By.xpath("//ion-button[contains(text(),'Từ chối')]"));
		
		List<Integer> sizeOfComponents = List.of(createrReq.size(), nameReq.size(), dayReq.size(), timeReq.size(), acptButtons.size());
		int minSize = Collections.min(sizeOfComponents);
		//		int minSize = Math.min(Math.min(createrReq.size(), nameReq.size()), Math.min(dayReq.size(), timeReq.size()));
		int requestIndex = 0;
		for (int i = 0; i < minSize; i++) {
		    String createrText = createrReq.get(i).getText();
		    String nameText = nameReq.get(i).getText();
		    String dayText = dayReq.get(i).getText();
		    String timeText = timeReq.get(i).getText();
		    
//		    System.out.println(String.format("%s, %s, %s, %s", createrText, nameText, dayText, timeText));
		    if (createrText.contains(username) && nameText.contains(requestType)
		            && dayText.contains(OTDay) && timeText.contains(startTime + " - " + endTime)) {
		    	requestIndex = i;
		    	System.out.println("Request " + nameText + " created by " + createrText + " on " + dayText + timeText + " is presented on screen.");
		        break;
		    }
		}
		return requestIndex;
	}
	
	public void acceptRequestWithReport(int requestIndex) throws InterruptedException 
	{
		openReviewReqPage();

	    String dayText = dayReq.get(requestIndex).getText();
	    String timeText = timeReq.get(requestIndex).getText();
	    String requestPresentText = dayText + timeText;
	    
		acptButtons.get(requestIndex).click(); // button Chấp thuận of request
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(@class, 'alert-message sc-ion-alert-md') and contains(text(), 'Xác nhận chấp nhận sự kiện?')]")));
	    driver.findElement(By.xpath("//div[contains(@class,'alert-wrapper')]//span[.='OK']")).click();
	    Thread.sleep(3000);	
	    
	    boolean isDayOnWaitReview = driver.getPageSource().contains(dayText);
	    boolean isTimeOnWaitReview = driver.getPageSource().contains(timeText);
	    
	    if (isDayOnWaitReview == false && isTimeOnWaitReview == false) {
	    	System.out.println("Request " + requestPresentText + " is delete on Chờ duyệt screen.");
	    }
	    WebElement acceptedBtn = driver.findElement(By.xpath("//div[@class='ion-page can-go-back']//ion-segment-button[.='Đã duyệt']"));
	    acceptedBtn.click();
	    Thread.sleep(3000);
	    
	    boolean isDayOnAcceptReview = driver.getPageSource().contains(dayText);
	    boolean isTimeOnAcceptReview = driver.getPageSource().contains(timeText);
	    
	    if (isDayOnAcceptReview == false && isTimeOnAcceptReview == false) {
	    	System.out.println("Request " + requestPresentText + " is accepted.");
	    }
	    WebElement statusChip = driver.findElement(By.xpath("//ion-chip"));
	    Assert.assertTrue(statusChip.getText().contains("Đã phê duyệt")); 
	}

	public void rejectRequest(int requestIndex, String username, String requestType, String OTDay, String startTime, String endTime) throws InterruptedException 
	{
		openReviewReqPage();

	    String dayText = dayReq.get(requestIndex).getText();
	    String timeText = timeReq.get(requestIndex).getText();
	    String requestPresentText = dayText + timeText;
	    
		denyButtons.get(requestIndex).click();
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(@class, 'alert-message sc-ion-alert-md') and contains(text(), 'Xác nhận hủy sự kiện')]")));
	    driver.findElement(By.xpath("//div[contains(@class,'alert-wrapper')]//span[.='OK']")).click();
	    Thread.sleep(3000);
	    
	    boolean isDayOnWaitReview = driver.getPageSource().contains(dayText);
	    boolean isTimeOnWaitReview = driver.getPageSource().contains(timeText);	    
	    
	    if (isDayOnWaitReview == false && isTimeOnWaitReview == false) {
	    	System.out.println("Request " + requestPresentText + " is delete on Chờ duyệt screen.");
	    }
	    WebElement acceptedBtn = driver.findElement(By.xpath("//div[@class='ion-page can-go-back']//ion-segment-button[.='Đã hủy']"));
	    acceptedBtn.click();
	    Thread.sleep(3000);
	    
	    boolean isDayOnAcceptReview = driver.getPageSource().contains(dayText);
	    boolean isTimeOnAcceptReview = driver.getPageSource().contains(timeText);
	    
	    if (isDayOnAcceptReview == true && isTimeOnAcceptReview == true) {
	    	System.out.println("Request " + requestPresentText + " is rejected.");
	    }
	}

	

}
