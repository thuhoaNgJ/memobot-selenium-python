package ClientSupportRequest;

import java.time.Duration;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import test.Login;

public class BookClientSupportReq {
	public WebDriver driver;
	private WebDriverWait wait;
	private JavascriptExecutor js;

	// components on Book OT popup
	String dateLocator = "document.querySelectorAll('ion-datetime-button')[0].shadowRoot.querySelector('slot')";
	String clickChooseMonthAndYearBox = "document.querySelector('ion-datetime[id=\"time\"]').shadowRoot.querySelector('.calendar-month-year').querySelector('ion-label').click()";
	String startTimeLocator = "document.querySelectorAll('ion-datetime-button')[1].shadowRoot.querySelector('slot')";
	String endTimeLocator = "document.querySelectorAll('ion-datetime-button')[2].shadowRoot.querySelector('slot')";
	String clickBookBtn = "document.querySelector('ion-button.button-custom').click()"; // button Đặt lịch
	String clickOverlayLocator = "document.querySelector('[class=\"ion-datetime-button-overlay md modal-default show-modal\"]').shadowRoot.querySelector('ion-backdrop').click()";
	
	public static void main(String[] args) throws InterruptedException {
		BookClientSupportReq bookReq = new BookClientSupportReq();
		bookReq.checkDefaultDateTime();
		bookReq.bookOTFailWithWrongTime();
		
		bookReq.bookOTRequest("27-01-2024", "08:00", "12:00");
		Integer reuquestIndex1 = bookReq.getIndexOfRequest("29-12-2023", "08:00", "12:00");
		bookReq.cancelRequest(reuquestIndex1, "29-12-2023", "13:30", "18:30");
		
		bookReq.bookOTRequest("20-01-2024", "13:30", "18:30");
		Integer requestIndex2 = bookReq.getIndexOfRequest("29-12-2023", "13:30", "18:30");
		bookReq.sendReport(requestIndex2, "Báo cáo support khách hàng");
		
//		
		bookReq.bookOTRequest("28-01-2024", "8:30", "12:00");
		Integer requestIndex3 = bookReq.getIndexOfRequest("27-12-2023", "14:30", "18:30");
		bookReq.sendReport(requestIndex3, "Báo cáo support khách hàng");
	}
	
	public BookClientSupportReq() 
	{
		Login login = new Login();
		login.setup();
		login.performLogin("user5@vais.vn", "dev@12345", "userTest5");
		this.driver = login.getDriver();
		wait = new WebDriverWait(driver, Duration.ofSeconds(20));
		js = (JavascriptExecutor) driver;
	}

	public void openBookingForm() 
	{
		boolean isTextPresent = driver.getPageSource().contains("Đặt lịch làm ngoài giờ");
		if (isTextPresent == false) {
			driver.get("https://nhansu-fe-dev.vais.vn");
			wait.until(ExpectedConditions.textToBePresentInElementLocated(By.xpath("//h3[@class='header-name']"),
					"Xin chào"));
			WebElement calendarBtn = driver.findElement(By.xpath("//ion-label[contains(text(),'Lịch')]"));
			calendarBtn.click();
			wait.until(ExpectedConditions
					.visibilityOfElementLocated(By.xpath("//ion-label[contains(text(),'Đăng ký lịch')]")));
			driver.findElement(By.xpath("//span[contains(text(),'Hỗ trợ khách')]")).click();
			wait.until(ExpectedConditions
					.visibilityOfElementLocated(By.xpath("//ion-title[contains(text(),'Hỗ trợ khách hàng')]")));
		}
	}

	public void openListRequestForm() throws InterruptedException 
	{
		boolean isTextPresent = driver.getPageSource().contains("Trạng thái phê duyệt");
		if (isTextPresent == false) {
			driver.get("https://nhansu-fe-dev.vais.vn");
			wait.until(ExpectedConditions.textToBePresentInElementLocated(By.xpath("//h3[@class='header-name']"),
					"Xin chào"));
			WebElement requestBtn = driver.findElement(By.xpath("//ion-label[contains(text(),'Phê duyệt')]"));
			requestBtn.click();
			Thread.sleep(3000);
		}
	}

	public void checkDefaultDateTime() 
{
		openBookingForm();

		// check default default date is the current date
		DateTimeFormatter formatterDate = DateTimeFormatter.ofPattern("d 'thg' M, yyyy");
		String defaultDate = (String) js.executeScript("return " + dateLocator + ".textContent");
		LocalDateTime dateNow = LocalDateTime.now();
		String formattedDate = dateNow.format(formatterDate);
		System.out.println("Text day on screen is " + defaultDate);
		System.out.println("Current day is " + formattedDate);

		Assert.assertTrue(defaultDate.contains(formattedDate));

		// check default start time and end time is the current time
		LocalDateTime timeNow = LocalDateTime.now();
		DateTimeFormatter formatterTime = DateTimeFormatter.ofPattern("HH:mm");
		String formattedTime = timeNow.format(formatterTime);

		String startTime = (String) js.executeScript("return " + startTimeLocator + ".textContent");
		String endTime = (String) js.executeScript("return " + endTimeLocator + ".textContent");

		Assert.assertTrue(startTime.contains(formattedTime) && endTime.contains(formattedTime));

		System.out.println("CHECK DONE DEFAULT DATE AND TIME.");
	}
	
	public void bookOTFailWithWrongTime() 
{
		openBookingForm();
		js.executeScript(clickBookBtn);
		String TimeValid = driver.findElement(By.xpath("//ion-label[@color='danger']")).getText();
		Assert.assertTrue(TimeValid.contains("Thời gian làm việc không nhỏ hơn 0"));
		System.out.println("CHECK DONE CANNOT CREATE OT WITH START DATE = END DATE");
	}

	public void bookOTRequest(String bookOTDay, String startOTTime, String endOTTime) throws InterruptedException 
{
		openBookingForm();
		js.executeScript(clickBookBtn);

		String[] dayArr = bookOTDay.split("-");
		Integer bookingDay = Integer.parseInt(dayArr[0]);
		Integer bookingMonth = Integer.parseInt(dayArr[1]);
		Integer bookingYear = Integer.parseInt(dayArr[2]);

		String[] startTimeArr = startOTTime.split(":");
		Integer startHour = Integer.parseInt(startTimeArr[0]);
		Integer startMinute = Integer.parseInt(startTimeArr[1]);

		String[] endTimeArr = endOTTime.split(":");
		Integer endHour = Integer.parseInt(endTimeArr[0]);
		Integer endMinute = Integer.parseInt(endTimeArr[1]);

		// CHOOSE DAY
		js.executeScript(dateLocator + ".click()"); // open calendar

		js.executeScript(clickChooseMonthAndYearBox);
		js.executeScript(
				"document.querySelector('ion-datetime#time').shadowRoot.querySelector('[class=\"month-column ion-color ion-color-primary md\"]').shadowRoot.querySelector('[data-value=\""
						+ bookingMonth + "\"').click()");
		Thread.sleep(1000);
		js.executeScript(
				"document.querySelector('ion-datetime#time').shadowRoot.querySelector('[class=\"year-column ion-color ion-color-primary md\"]').shadowRoot.querySelector('[data-value=\""
						+ bookingYear + "\"').click()");
		Thread.sleep(1000);
		js.executeScript(clickChooseMonthAndYearBox);

		js.executeScript(
				"document.querySelector('ion-datetime[id=\"time\"]').shadowRoot.querySelectorAll('.calendar-month-grid')[1].querySelector('[data-day=\""
						+ bookingDay + "\"]').click()");
		Thread.sleep(1000);
		js.executeScript(clickOverlayLocator); // close calendar

		// CHOOSE START TIME
		js.executeScript(startTimeLocator + ".click()");
		js.executeScript(
				"document.querySelector('ion-datetime#fromDate').shadowRoot.querySelectorAll('ion-picker-column-internal')[0].shadowRoot.querySelector('[data-value=\""
						+ startHour + "\"').click()");
		Thread.sleep(1000);
		js.executeScript(
				"document.querySelector('ion-datetime#fromDate').shadowRoot.querySelectorAll('ion-picker-column-internal')[1].shadowRoot.querySelector('[data-value=\""
						+ startMinute + "\"').click()");
		Thread.sleep(1000);
		js.executeScript(clickOverlayLocator); // close scroll time-picker

		// CHOOSE END TIME
		js.executeScript(endTimeLocator + ".click()");
		Thread.sleep(1000);
		js.executeScript(
				"document.querySelector('ion-datetime#toDate').shadowRoot.querySelectorAll('ion-picker-column-internal')[0].shadowRoot.querySelector('[data-value=\""
						+ endHour + "\"').click()");
		Thread.sleep(1000);
		js.executeScript(
				"document.querySelector('ion-datetime#toDate').shadowRoot.querySelectorAll('ion-picker-column-internal')[1].shadowRoot.querySelector('[data-value=\""
						+ endMinute + "\"').click()");
		Thread.sleep(1000);
		js.executeScript(clickOverlayLocator); // close scroll time-picker

		// CLICK BUTTON ĐẶT LỊCH
		js.executeScript(clickBookBtn);
	}
	
	public void checkListRequest(String bookOTDay, String startOTTime, String endOTTime) throws InterruptedException 
{
		openListRequestForm();
		boolean isDayPresent = driver.getPageSource().contains(bookOTDay);
		boolean isTimePresent = driver.getPageSource().contains(startOTTime + " - " + endOTTime);
		if (isDayPresent == true && isTimePresent == true) {
			System.out.println("Request is present on Chờ duyệt screen.");
		} else {
			System.out.println("Request is not present on Chờ duyệt screen.");
		}
	}

	public int getIndexOfRequest(String bookOTDay, String startOTTime, String endOTTime) 
{
		String OTTimeString = startOTTime + " - " + endOTTime;
		List<WebElement> OTDayText = driver.findElements(By.xpath("//ion-card-content//ion-label//span[1]"));
		List<WebElement> OTTimeText = driver.findElements(By.xpath("//ion-card-content//ion-label//span[2]"));

		boolean isRequestPresent = false;
		int requestIndex = 0;
		for (int i = 0; i < OTDayText.size(); i++) {
			String day = OTDayText.get(i).getText();
			String time = OTTimeText.get(i).getText();
			if (day.contains(bookOTDay) && time.contains(OTTimeString)) {
				requestIndex = i;
				isRequestPresent = true;
				break;
			}
		}
		return requestIndex;
	}

	public void sendReport(int requestIndex, String reportContent) throws InterruptedException 
{
		openListRequestForm();

		List<WebElement> sendReportBtns = driver.findElements(By.xpath("//span[contains(text(),'Báo cáo')]"));
		sendReportBtns.get(requestIndex).click();
		wait.until(ExpectedConditions
				.visibilityOfElementLocated(By.xpath("//textarea[@placeholder='Nhập công việc đã làm']")));
		driver.findElement(By.xpath("//textarea[@placeholder='Nhập công việc đã làm']")).sendKeys(reportContent);
		WebElement reportConfirmBtn = driver
				.findElement(By.cssSelector("ion-button[class*='md button button-clear button-strong']"));
		reportConfirmBtn.click();
		Thread.sleep(2000);

		boolean isTextPresent = driver.getPageSource().contains(reportContent);
		if (isTextPresent == true) {
			System.out.println("Send report successfully.");
		}
	}

	public void cancelRequest(int requestIndex, String bookOTDay, String startOTTime, String endOTTime) throws InterruptedException 
	{
		String requestText = bookOTDay + " - " + startOTTime + " - " + endOTTime;
		System.out.println(requestText);
		
		openListRequestForm();
		Thread.sleep(2000);

		List<WebElement> cancelReportBtns = driver.findElements(By.xpath("//ion-button[contains(text(),'Hủy')]"));
		cancelReportBtns.get(requestIndex).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[.='Xác nhận hủy sự kiện ']")));
		driver.findElement(By.xpath("//span[.='OK']")).click();
		wait.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath("//div[.='Xác nhận hủy sự kiện ']")));
//		Thread.sleep(3000);
		
		List<WebElement> reviewOTDayText = driver.findElements(By.xpath("//ion-card-content//ion-label//span[1]"));
		List<WebElement> reviewOTTimeText = driver.findElements(By.xpath("//ion-card-content//ion-label//span[2]"));

		System.out.println("Total request on Chờ duyệt screen: " + reviewOTDayText.size());
		if (reviewOTDayText.size() == 0) 
		{
			System.out.println("Request is removed on Chờ duyệt screen.");
		}else
		{
			for(int i=0; i < reviewOTDayText.size(); i++)
			{
				String presentText = reviewOTDayText.get(i).getText() + reviewOTTimeText.get(i).getText();
				boolean isRequestPresent = presentText.contains(requestText);
				if (isRequestPresent == false) 
				{
					System.out.println("Request is deleted on Chờ duyệt screen.");
				}
			}
		}

		driver.findElement(By.xpath("//ion-segment-button[.='Đã hủy']")).click();
		Thread.sleep(3000);

		List<WebElement> cancelOTDayText = driver.findElements(By.xpath("//ion-card-content//ion-label//span[1]"));
		List<WebElement> cancelOTTimeText = driver.findElements(By.xpath("//ion-card-content//ion-label//span[2]"));

		for(int i=0; i < cancelOTDayText.size(); i++)
		{
			String presentText = cancelOTDayText.get(i).getText() + " " + cancelOTTimeText.get(i).getText();
			System.out.println(presentText);
			boolean isRequestPresent = presentText.contains(requestText);
			if (isRequestPresent == true) 
			{
				System.out.println("Request is presented on Đã hủy screen.");
				break;
			}
		}
		
		Integer cancelRequestIndex = getIndexOfRequest(bookOTDay, startOTTime, endOTTime);
		List<WebElement> statusChip = driver.findElements(By.xpath("//ion-card//ion-row[1]//ion-chip"));
		Assert.assertTrue(statusChip.get(cancelRequestIndex).getText().contains("Đã hủy"));
	}

	
}























