/*
 * check these following steps:
 * 1. check book WFH request fail with blank field 
 * 2. Check book WFH request fail with exits day and time
 * 3. check book WFH request successfully
 * 4. check created request is presented on Chờ duyệt screen
*/
package WfhRequest;

import java.time.Duration;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Collections;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import test.Login;

public class BookWfhRequest {
	public WebDriver driver;
	private WebDriverWait wait;
	private JavascriptExecutor js;

	public WebElement calendarBtn;
	String formattedTime;
	String formattedDate;

	String createdReason = "Test auto lý do WFH";
	String createdPlan = "Test kế hoạch WFH";
	String bookingDay;
	String bookingTime;
	
	List<WebElement> nameReq;
	List<WebElement> dayReq;
	List<WebElement> timeReq;
	List<WebElement> reportButtons;
	List<WebElement> denyButtons;

	public static void main(String[] args) throws InterruptedException {
		BookWfhRequest bookReq = new BookWfhRequest();
		bookReq.testCreateRequestWithBlankField();
		
		String createdDay = bookReq.createWfhRequest("25", "Buổi sáng");
		int requestIndex1 = bookReq.checkListRequest("25","buổi sáng");
		bookReq.sendReportRequest(requestIndex1,"Test thêm nội dung báo cáo wfh");

		bookReq.createWfhRequest("25", "Buổi chiều");
		int requestIndex2 = bookReq.checkListRequest("25","buổi chiều");
		bookReq.sendReportRequest(requestIndex2,"Test thêm nội dung báo cáo wfh");
	
		bookReq.createFailWithExistedTime("25", "Buổi sáng");
	}

	public BookWfhRequest() {
		Login login = new Login();
		login.setup();
		login.performLogin("user5@vais.vn", "dev@12345", "userTest5");
		this.driver = login.getDriver();
		wait = new WebDriverWait(driver, Duration.ofSeconds(20));
		js = (JavascriptExecutor) driver;
	}

	public void openWfmForm() {
		driver.get("https://nhansu-fe-dev.vais.vn");
		wait.until(
				ExpectedConditions.textToBePresentInElementLocated(By.xpath("//h3[@class='header-name']"), "Xin chào"));
		calendarBtn = driver.findElement(By.xpath("//ion-label[contains(text(),'Lịch')]"));
		calendarBtn.click();
		wait.until(ExpectedConditions
				.visibilityOfElementLocated(By.xpath("//ion-label[contains(text(),'Đăng ký lịch')]")));
		driver.findElement(By.xpath("//span[contains(text(),'Làm tại nhà')]")).click();
		wait.until(ExpectedConditions
				.visibilityOfElementLocated(By.xpath("//ion-title[contains(text(),'Đặt lịch làm tại nhà')]")));
	}

	public void testCreateRequestWithBlankField() {
		boolean isTextPresent = driver.getPageSource().contains("Đặt lịch làm tại nhà");
		if (isTextPresent == false) {
			openWfmForm();
		}
		;
		js.executeScript(
				"document.querySelector(\".ion-margin.button-custom.ion-color.ion-color-tertiary.md.button.button-block.button-round.button-outline.ion-activatable.ion-focusable\")"
						+ ".shadowRoot.querySelector(\".button-native\").click()");

		String pageSource = driver.getPageSource();
		Assert.assertTrue(pageSource.contains("Lý do không được để trống"));
		Assert.assertTrue(pageSource.contains("Kế hoạch làm việc không được để trống"));
		Assert.assertTrue(pageSource.contains("Hãy chọn buổi trong ngày"));

		System.out.println("CHECK DONE CANNOT EMPTY BOOK WFH FIELD");
	}

	public String createWfhRequest(String bookingDay, String bookingTime) throws InterruptedException {
		boolean isTextPresent = driver.getPageSource().contains("Đặt lịch làm tại nhà");
		if (isTextPresent == false) {
			openWfmForm();
		}
		;

		driver.findElement(By.cssSelector("textarea[placeholder='Nhập lý do']")).sendKeys(createdReason);
		driver.findElement(By.cssSelector("textarea[placeholder='Nhập kế hoạch làm việc']")).sendKeys(createdPlan);

		// Check WFH's default date is the present day
		String defaultDateWFH = driver.findElement(By.xpath("(//ion-note)[1]")).getText();
		LocalDateTime now = LocalDateTime.now();
		String formattedDate = now.format(DateTimeFormatter.ofPattern("dd-MM-yyyy"));
		Assert.assertEquals(formattedDate, defaultDateWFH);

		// choose day 25th of current month
		driver.findElement(By.xpath("//ion-label[normalize-space()='Ngày:']")).click(); // open calendar box
		Thread.sleep(3000);
		js.executeScript(
				"document.querySelector('[class*=\"datetime-presentation-date\"]').shadowRoot.querySelector('.datetime-calendar').querySelector('.calendar-body.ion-focusable').querySelector('.calendar-month:nth-child(2)').querySelector('[data-day=\""
						+ bookingDay + "\"]').click()");

		// click overlay to close calendar
		js.executeScript("return document.querySelector('.date-picker.bottom-end.md.modal-default.show-modal')"
				+ ".shadowRoot.querySelector('[part=\"backdrop\"]').click()");

		String createdDay = driver
				.findElement(By.xpath("//ion-note[@class='ion-color ion-color-medium md form-value']")).getText();
		System.out.println(createdDay); // 25-11-2023

//		Choose "buổi"
		js.executeScript(
				"document.querySelector('.md.in-item.has-placeholder.ion-focusable.select-ltr.select-justify-space-between.select-label-placement-start')"
						+ ".shadowRoot.querySelector('.select-wrapper').querySelector('.native-wrapper').querySelector('[part=\"placeholder\"]').click()");

		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'Buổi sáng')]")));
		driver.findElement(By.xpath("//div[contains(text(),'" + bookingTime + "')]")).click();
		driver.findElement(By.xpath("//span[normalize-space()='OK']")).click();
		Thread.sleep(3000);

		String chooseTime = (String) js.executeScript(
				"return document.querySelector('[class*=\"ion-focusable select-ltr\"]').shadowRoot.querySelector('.select-wrapper').querySelector('div').querySelector('div').textContent");
		String createTime = chooseTime.toLowerCase();
		System.out.println(createTime);

		// Click button "Đặt lịch"
		js.executeScript("document.querySelector(\".ion-margin.button-custom.ion-color.ion-color"
				+ "-tertiary.md.button.button-block.button-round.button-outline.ion-activatable.ion-focusable\")"
				+ ".shadowRoot.querySelector(\".button-native\").click()");
		Thread.sleep(5000);

		String bookingInfor = "Làm tại nhà" + ", " + createdDay + ", " + createTime;
		System.out.println("Request in booking 'Làm tại nhà' screen is:" + bookingInfor);
		return createdDay;
	}

	public void createFailWithExistedTime(String bookingDay, String bookingTime) throws InterruptedException {
		WebElement requestBtn = driver.findElement(By.xpath("//ion-label[contains(text(),'Phê duyệt')]"));
		requestBtn.click();
		Thread.sleep(3000);
		String pageSourceText = driver.getPageSource();
		if (!pageSourceText.contains(bookingDay) && !pageSourceText.contains(bookingTime)) {
			createWfhRequest(bookingDay, bookingTime);
		}
		createWfhRequest(bookingDay, bookingTime);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h2[contains(text(),'Có lỗi xảy ra')]")));
		String text = driver.findElement(By.xpath("//div[@class='alert-message sc-ion-alert-md']")).getText();
		Assert.assertTrue(text.contains("Không được book trùng lịch. Bạn bị trùng lịch wfh"));
		System.out.println("CHECK DONE CANNOT CREATE REQUEST WITH EXIST TIME.");
	}
	
	public void goToListCreatedRequest() throws InterruptedException 
	{
		driver.get("https://nhansu-fe-dev.vais.vn");
		wait.until(ExpectedConditions.textToBePresentInElementLocated(By.xpath("//h3[@class='header-name']"), "Xin chào"));
		WebElement requestBtn = driver.findElement(By.xpath("//ion-label[contains(text(),'Phê duyệt')]"));
		requestBtn.click();
		Thread.sleep(3000);
	}

	
	public int checkListRequest(String bookingDay, String bookingTime) throws InterruptedException 
	{
		boolean isTextPresent = driver.getPageSource().contains("Trạng thái phê duyệt");
		if (isTextPresent == false) {
			goToListCreatedRequest();
		}
		;
		List<WebElement> statusChip = driver.findElements(By.xpath("//ion-card//ion-row[1]//ion-chip"));
		
		boolean isRequestPresent = false;

		nameReq = driver.findElements(By.xpath("//ion-card//ion-row[1]//ion-label")); 
		dayReq = driver.findElements(By.xpath("//ion-card//ion-row[2]//span[1]"));
		timeReq = driver.findElements(By.xpath("//ion-card//ion-row[2]//span[2]"));
		reportButtons = driver.findElements(By.xpath("//ion-button[contains(.,'Báo cáo')]"));
		denyButtons = driver.findElements(By.xpath("//ion-button[contains(.,'Hủy')]"));
		
		List<Integer> sizeOfComponents = List.of(nameReq.size(), dayReq.size(), timeReq.size(), reportButtons.size());
		int minSize = Collections.min(sizeOfComponents);
		int requestIndex = 0;
		for (int i = 0; i < minSize; i++) {
		    String nameText = nameReq.get(i).getText();
		    String dayText = dayReq.get(i).getText();
		    String timeText = timeReq.get(i).getText();
		    
		    //System.out.println(String.format("%s, %s, %s, %s", createrText, nameText, dayText, timeText));
		    if (dayText.contains(bookingDay) && timeText.contains(bookingTime)) 
		    {
		    	requestIndex = i;
		    	isRequestPresent = true;
		    	System.out.println("Request " + nameText + " on " + dayText + timeText + " is presented on Chờ duyệt screen.");
		        break;
		    }
		}
		
		Assert.assertTrue(statusChip.get(requestIndex).getText().contains("Chờ duyệt")); // request's status
		System.out.println("Status of request is " + statusChip.get(requestIndex).getText());
		return requestIndex;
	}
	
	
	public void sendReportFailWithBlankTextbox(int requestIndex) throws InterruptedException 
	{
		boolean isTextPresent = driver.getPageSource().contains("Trạng thái phê duyệt");
		if (isTextPresent == false) {
			goToListCreatedRequest();
		}
		;
		reportButtons.get(requestIndex).click();
		Thread.sleep(3000);
		WebElement reportConfirmBtn = driver
				.findElement(By.cssSelector("ion-button[class*='md button button-clear button-strong']"));
		reportConfirmBtn.click();
		Assert.assertTrue(driver.findElement(By.cssSelector("ion-label[class*='error-line']")).getText()
				.contains("Nội dung báo cáo không được để trống"));
		System.out.println("Check done the Report Box must not be left empty");
	}
	
	
	public void sendReportRequest(int requestIndex, String reportContent) throws InterruptedException 
	{
		boolean isTextPresent = driver.getPageSource().contains("Trạng thái phê duyệt");
		if (isTextPresent == false) {
			goToListCreatedRequest();
		}
		;
		reportButtons.get(requestIndex).click();
		driver.findElement(By.xpath("//textarea")).sendKeys(reportContent);
		WebElement reportConfirmBtn = driver
				.findElement(By.cssSelector("ion-button[class*='md button button-clear button-strong']"));
		reportConfirmBtn.click();
		Thread.sleep(3000);
		
	}
	

}
